import 'dotenv/config';
const t0 = Date.now();
require('cloudinary');
console.log('cloudinary:', Date.now() - t0 + 'ms');
const t1 = Date.now();
require('validator');
console.log('validator:', Date.now() - t1 + 'ms');
process.exit(0);
