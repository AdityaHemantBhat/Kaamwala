import 'dotenv/config';
(async () => {
  const t = async (label: string, imp: Promise<any>) => {
    const s = Date.now();
    try { await imp; } catch (e: any) { console.log(label, 'ERROR', e.message); }
    console.log(label, Date.now() - s + 'ms');
  };
  await t('express', import('express'));
  await t('@prisma/client', import('@prisma/client'));
  await t('zod', import('zod'));
  await t('winston', import('winston'));
  await t('jsonwebtoken', import('jsonwebtoken'));
  await t('bcrypt', import('bcrypt'));
  await t('axios', import('axios'));
  await t('firebase-admin', import('firebase-admin'));
  await t('cloudinary', import('cloudinary'));
  await t('twilio', import('twilio'));
  await t('socket.io', import('socket.io'));
  await t('redis(client)', import('redis'));
  await t('multer', import('multer'));
  await t('cashfree-pg', import('cashfree-pg'));
  await t('validator', import('validator'));
  await t('express-rate-limit', import('express-rate-limit'));
  await t('helmet', import('helmet'));
  await t('morgan', import('morgan'));
  process.exit(0);
})();
