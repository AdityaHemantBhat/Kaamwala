const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function run() {
  const users = await prisma.user.findMany({
    where: { name: { contains: 'aditya', mode: 'insensitive' } },
    include: { 
      bookingsAsCustomer: { include: { address: true } }
    }
  });

  for (const user of users) {
    if (user.bookingsAsCustomer) {
      for (const booking of user.bookingsAsCustomer) {
        if (booking.addressId) {
          await prisma.address.update({
            where: { id: booking.addressId },
            data: { latitude: 15.0118, longitude: 74.0227, city: 'Canacona', state: 'Goa', line1: 'Canacona' }
          });
        }
        console.log('Updated booking ' + booking.id + ' address to Canacona');
      }
    }
  }

  // Update all addresses belonging to Aditya
  for (const user of users) {
    const addresses = await prisma.address.findMany({ where: { userId: user.id } });
    for (const addr of addresses) {
      await prisma.address.update({
        where: { id: addr.id },
        data: { latitude: 15.0118, longitude: 74.0227, city: 'Canacona', state: 'Goa', line1: 'Canacona' }
      });
      console.log('Updated address ' + addr.id);
    }
  }
}

run().catch(console.error).finally(() => prisma.$disconnect());
