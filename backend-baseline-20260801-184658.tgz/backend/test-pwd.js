const { PrismaClient } = require('@prisma/client');

const passwords = ['postgres', 'admin', 'root', 'password', '1234', '123456', ''];

async function testPasswords() {
  for (const pwd of passwords) {
    console.log('Testing password: ' + pwd);
    process.env.DATABASE_URL = `postgresql://postgres:${pwd}@localhost:5432/postgres?schema=public`;
    const prisma = new PrismaClient();
    try {
      await prisma.$connect();
      console.log('SUCCESS! The password is: ' + (pwd === '' ? '(blank)' : pwd));
      return;
    } catch (e) {
      // ignore
    } finally {
      await prisma.$disconnect();
    }
  }
  console.log('FAILED to find default password.');
}

testPasswords();
