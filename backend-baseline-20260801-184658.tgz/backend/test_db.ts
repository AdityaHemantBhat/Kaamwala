import { prisma } from './src/config/prisma';

async function main() {
  const workers = await prisma.workerProfile.findMany({
    include: {
      user: true,
    }
  });

  for (const w of workers) {
    console.log(`WorkerProfile ID: ${w.id} | User ID: ${w.userId} | Name: ${w.user?.name}`);
  }
}

main().catch(console.error).finally(() => prisma.$disconnect());
