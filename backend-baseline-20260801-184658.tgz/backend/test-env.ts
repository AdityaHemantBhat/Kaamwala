import { config } from 'dotenv';
config();
console.log('Raw ENV:', process.env.FIREBASE_SERVICE_ACCOUNT_JSON?.substring(0, 100));
try {
  const parsed = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON || '{}');
  console.log('Parsed private key:', parsed.private_key?.substring(0, 100));
  console.log('Contains newline?', parsed.private_key?.includes('\n'));
  console.log('Contains literal \\n?', parsed.private_key?.includes('\\n'));
} catch (e) {
  console.log('Parse error:', e);
}
