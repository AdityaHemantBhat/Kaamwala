// End-to-end smoke test for the marketplace flows (run against a seeded dev DB).
// Run: npx ts-node scripts/smoke-test.ts
import { prisma } from '../src/config/prisma';

const BASE = 'http://localhost:5000/api/v1';
let failures = 0;

function ok(name: string, cond: boolean, detail = '') {
  if (cond) console.log(`  ✅ ${name}`);
  else { failures++; console.log(`  ❌ ${name} ${detail}`); }
}

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

async function login(phone: string, role: string) {
  await sleep(65000); // auth limiter is 5 req/min; each login uses 2 → space logins across minutes
  await fetch(`${BASE}/auth/send-otp`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone }) });
  const res = await fetch(`${BASE}/auth/verify-otp`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone, otp: '123456', role }) });
  const json = await res.json();
  if (!json.data?.accessToken) throw new Error(`Login failed for ${phone}: ${JSON.stringify(json)}`);
  return { token: json.data.accessToken, user: json.data.user };
}

function auth(token: string) { return { 'Content-Type': 'application/json', Authorization: `Bearer ${token}`, 'x-app-version': '2.0.0' }; }
async function api(method: string, path: string, token: string, body?: any) {
  const res = await fetch(BASE + path, { method, headers: auth(token), body: body ? JSON.stringify(body) : undefined });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, json };
}

async function main() {
  // ── 1. Logins ──
  console.log('\n▶ Logins (OTP bypass 123456)');
  const neha = await login('+919876502001', 'CUSTOMER');       // Delhi customer
  const ramesh = await login('+919876501001', 'WORKER');       // PLUMBER, verified
  const arjun = await login('+919876501006', 'WORKER');        // AC_TECHNICIAN, urgent-eligible
  const amit = await login('+919876502005', 'CUSTOMER');       // Pune customer
  ok('Customer login (Neha)', !!neha.token);
  ok('Worker login (Ramesh)', !!ramesh.token);
  ok('Worker login (Arjun)', !!arjun.token);

  // ── 2. Worker plans FREE/PRO/ELITE ──
  console.log('\n▶ Worker plans (Part 60-69)');
  const plans = await api('GET', '/workers/subscription/plans', arjun.token);
  const planNames = (plans.json.data || []).map((p: any) => p.id).join(',');
  ok('Plans are FREE/PRO/ELITE', planNames === 'FREE,PRO,ELITE', `got ${planNames}`);
  const mySub = await api('GET', '/workers/subscription/my', arjun.token);
  ok('Worker default plan is FREE (15%)', mySub.json.data?.plan === 'FREE' && mySub.json.data?.commission === 15, JSON.stringify(mySub.json.data));

  // Activate PRO (test-mode verify is idempotent)
  const verify = await api('POST', '/workers/subscription/verify', arjun.token, { orderId: `test_${Date.now()}`, plan: 'PRO' });
  ok('Activate PRO (10%)', verify.status === 200, JSON.stringify(verify.json));
  const mySub2 = await api('GET', '/workers/subscription/my', arjun.token);
  ok('PRO active with 10% commission', mySub2.json.data?.plan === 'PRO' && mySub2.json.data?.commission === 10, JSON.stringify(mySub2.json.data));

  // ── 3. Normal request + recommendation + quote + accept ──
  console.log('\n▶ Normal Post-Request (Parts 2, 113-117, 51-54)');
  const addrs = await api('GET', '/addresses', neha.token);
  const addr = addrs.json.data?.find((a: any) => a.isDefault) || addrs.json.data?.[0];
  ok('Customer has an address for service location', !!addr?.id, JSON.stringify(addrs.json));

  const rec = await api('POST', '/requests/recommendation', neha.token, {
    category: 'PLUMBER', pricingUnit: 'FLAT', issueId: null, addressId: addr.id,
  });
  ok('Price recommendation returned with recommendationExposed', rec.json.data?.recommendationExposed === true && rec.json.data?.reference > 0, JSON.stringify(rec.json));

  const req = await api('POST', '/requests', neha.token, {
    title: 'Fix leaking tap in kitchen', description: 'Tap is leaking water continuously', category: 'PLUMBER',
    issueId: null, addressId: addr.id, budget: 300, budgetType: 'negotiable', pricingUnit: 'FLAT',
    scope: { taps: 1 },
  });
  ok('Customer created request', req.status === 201, JSON.stringify(req.json));
  const requestId = req.json.data?.id;

  // Worker floor validation
  const lowQuote = await api('POST', `/requests/${requestId}/quote`, ramesh.token, { amount: 10, pricingUnit: 'FLAT' });
  ok('Worker quote below floor rejected', lowQuote.status === 400, JSON.stringify(lowQuote.json));

  const quote = await api('POST', `/requests/${requestId}/quote`, ramesh.token, { amount: 320, pricingUnit: 'FLAT', message: 'Can fix within an hour' });
  ok('Worker quote accepted', quote.status === 200, JSON.stringify(quote.json));

  const offers = await api('GET', `/requests/${requestId}/offers`, neha.token);
  ok('Offer history recorded (WORKER quote)', (offers.json.data || []).length >= 1 && offers.json.data[0]?.offeredBy === 'WORKER', JSON.stringify(offers.json));

  const interest = await api('GET', `/requests/${requestId}/interests`, neha.token);
  const interestId = interest.json.data?.[0]?.id;
  ok('Interest carries worker quote', interestId && interest.json.data[0]?.quoteAmount === 320, JSON.stringify(interest.json));

  const accept = await api('POST', `/requests/${requestId}/accept`, neha.token, { interestId });
  ok('Customer accepted worker quote → ASSIGNED', accept.status === 200, JSON.stringify(accept.json));
  const reqAfter = (await api('GET', '/requests', neha.token)).json.data.find((r: any) => r.id === requestId);
  ok('finalAgreedAmount snapshot = 320', reqAfter?.finalAgreedAmount === 320, JSON.stringify(reqAfter));

  const booking = await api('POST', `/requests/${requestId}/create-booking`, neha.token, { scheduledAt: new Date(Date.now() + 3600000).toISOString() });
  console.log('  [debug] create-booking response:', booking.status, JSON.stringify(booking.json));
  ok('Booking created from request', booking.status === 201, JSON.stringify(booking.json));
  const bookingId = booking.json.data?.id;
  // Ramesh is seeded as PRO (workers[0] → PRO subscription) → 10% plan-derived commission.
  ok('Booking uses plan-derived commission (Ramesh seeded PRO → fee ₹32 on ₹320)', booking.json.data?.platformFee === 32 && booking.json.data?.platformFeePercent === 10, `fee=${booking.json.data?.platformFee} pct=${booking.json.data?.platformFeePercent}`);

  // ── 4. Urgent — zero eligible fast-fail (PLUMBER has no urgent-eligible worker) ──
  console.log('\n▶ Urgent matching (Parts 60-61, 79)');
  const urgentPlumber = await api('POST', '/urgent/request', neha.token, { category: 'PLUMBER', issueReason: 'Pipe burst', description: 'Water everywhere', pricingUnit: 'FLAT' });
  ok('PLUMBER urgent → NO_ELIGIBLE_WORKERS fast-fail', urgentPlumber.status === 409 && String(urgentPlumber.json.error).includes('NO_ELIGIBLE_WORKERS'), `${urgentPlumber.status} ${JSON.stringify(urgentPlumber.json)}`);

  // ── 5. Urgent — successful match (Pune customer + AC Arjun within radius) ──
  // Arjun is seeded with IN_PROGRESS bookings → busy-excluded (Part 86). Clear them
  // so the success path can be exercised.
  const cleared = await prisma.booking.updateMany({
    where: { workerId: arjun.user.id, status: { in: ['ACCEPTED', 'ON_THE_WAY', 'IN_PROGRESS'] } },
    data: { status: 'COMPLETED', completedAt: new Date() },
  });
  const arjunDb = await prisma.workerProfile.findUnique({ where: { userId: arjun.user.id } });
  const amitAddr = (await prisma.address.findFirst({ where: { userId: amit.user.id, isDefault: true } }));
  const dlat = ((arjunDb?.latitude ?? 0) - (amitAddr?.latitude ?? 0)); const dlng = ((arjunDb?.longitude ?? 0) - (amitAddr?.longitude ?? 0));
  console.log('  [debug] cleared busy:', cleared.count, '| arjun online/avail/verified/urgent:', arjunDb?.isOnline, arjunDb?.isAvailable, arjunDb?.verificationStatus, arjunDb?.isUrgentEligible);
  console.log('  [debug] amit->arjun approx km:', (Math.sqrt(dlat * dlat + dlng * dlng) * 111).toFixed(1), '| radius:', arjunDb?.serviceRadiusKm);
  const preview = await api('POST', '/urgent/preview', amit.token, { category: 'AC_TECHNICIAN', pricingUnit: 'FLAT' });
  const base = preview.json.data?.basePrice;
  const initial = preview.json.data?.initialOffer;
  ok('Urgent preview = 1.3x base server-computed', Math.abs(initial - Math.round(base * 1.3)) <= 1, JSON.stringify(preview.json.data));

  const urgentAc = await api('POST', '/urgent/request', amit.token, { category: 'AC_TECHNICIAN', issueReason: 'AC not cooling', description: 'AC blowing warm air', pricingUnit: 'FLAT' });
  console.log('  [debug] AC urgent response:', urgentAc.status, JSON.stringify(urgentAc.json));
  ok('AC urgent created (eligible worker found)', urgentAc.status === 200, JSON.stringify(urgentAc.json));
  const urgentId = urgentAc.json.data?.requestId;

  // Recompute base from DB snapshot
  const ur = await prisma.urgentRequest.findUnique({ where: { id: urgentId } });
  ok('Server-authoritative base snapshot stored', ur?.basePriceSnapshot != null && ur.basePriceSnapshot > 0, JSON.stringify(ur));
  ok('offerVersion starts at 0', ur?.offerVersion === 0, `v=${ur?.offerVersion}`);

  const boost = await api('POST', '/urgent/increase-offer', amit.token, { requestId: urgentId, increaseAmount: 100 });
  ok('Boost increased offer (offerVersion increments)', boost.json.data?.newOffer > ur!.currentOffer, JSON.stringify(boost.json));
  const ur2 = await prisma.urgentRequest.findUnique({ where: { id: urgentId } });
  ok('offerVersion incremented on boost', ur2?.offerVersion === 1, `v=${ur2?.offerVersion}`);

  const acceptUrgent = await api('POST', '/urgent/accept', arjun.token, { requestId: urgentId, offerVersion: ur2?.offerVersion });
  ok('Urgent accepted atomically by Arjun', acceptUrgent.status === 200, JSON.stringify(acceptUrgent.json));
  const urgentBookingId = acceptUrgent.json.data?.bookingId;

  // Second accept must lose the race
  const acceptAgain = await api('POST', '/urgent/accept', arjun.token, { requestId: urgentId });
  ok('Second accept rejected (atomic acceptance)', acceptAgain.status === 400, JSON.stringify(acceptAgain.json));

  // Commission = 10% of base only (PRO), premium + boost to worker
  const ub = await prisma.booking.findUnique({ where: { id: urgentBookingId } });
  const expectedCommission = Math.round((ur!.basePriceSnapshot * 10) / 100);
  ok('Urgent commission = 10% of FROZEN BASE only', ub?.platformFee === expectedCommission, `fee=${ub?.platformFee} expected=${expectedCommission}`);
  ok('Urgent worker earnings = offer − commission', ub!.workerEarnings === (ub!.totalAmount ?? 0) - (ub!.platformFee ?? 0), `earnings=${ub?.workerEarnings} offer=${ub?.totalAmount}`);

  // ── 6. Completion → payout idempotency ──
  console.log('\n▶ Completion + payout (Parts 128-129)');
  // processPayout fires from both payment-verify AND the COMPLETED transition.
  // Calling it twice must credit the worker only once.
  const { bookingService } = await import('../src/services/booking.service');
  await bookingService.processPayout(bookingId);
  await bookingService.processPayout(bookingId);
  await bookingService.processPayout(bookingId);
  const payouts = await prisma.transaction.count({ where: { bookingId, type: 'WALLET_CREDIT' } });
  ok('Payout is idempotent (no double credit)', payouts === 1, `payouts=${payouts}`);
  const commissionRows = await prisma.transaction.count({ where: { bookingId, type: 'PLATFORM_COMMISSION' } });
  ok('Explicit commission ledger row written', commissionRows >= 1, `rows=${commissionRows}`);

  console.log(failures === 0 ? '\n✅ ALL SMOKE TESTS PASSED' : `\n❌ ${failures} SMOKE TEST(S) FAILED`);
  process.exit(failures === 0 ? 0 : 1);
}

main().catch((e) => { console.error('Smoke test crashed:', e); process.exit(1); });
