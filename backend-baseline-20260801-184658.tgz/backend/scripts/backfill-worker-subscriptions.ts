// Backfill: migrate worker subscriptions from UserSubscription (BASIC/PLUS/PRO)
// to WorkerSubscription (FREE/PRO/ELITE). Only rows belonging to actual workers move;
// customer subscriptions are untouched.
// Mapping: BASIC → FREE, PLUS → PRO, PRO → ELITE
// Run: npx ts-node scripts/backfill-worker-subscriptions.ts
import { prisma } from '../src/config/prisma';

const MAP: Record<string, string> = { BASIC: 'FREE', PLUS: 'PRO', PRO: 'ELITE' };

async function main() {
  // All users that have a worker profile
  const workers = await prisma.workerProfile.findMany({ select: { userId: true } });
  const workerIds = new Set(workers.map((w) => w.userId));

  const subs = await prisma.userSubscription.findMany();
  let moved = 0;
  for (const sub of subs) {
    if (!workerIds.has(sub.userId)) continue; // customer subscription — leave alone
    const newPlan = (MAP[sub.plan] || 'FREE') as any; // cast to WorkerPlan enum
    const data: any = {
      userId: sub.userId,
      plan: newPlan,
      status: sub.status === 'active' ? 'active' : 'expired',
      currentPeriodStart: sub.currentPeriodStart,
      currentPeriodEnd: sub.currentPeriodEnd,
      cancelledAt: sub.cancelledAt,
    };
    await prisma.workerSubscription.upsert({
      where: { userId: sub.userId },
      update: { plan: newPlan, status: data.status, currentPeriodStart: sub.currentPeriodStart, currentPeriodEnd: sub.currentPeriodEnd },
      create: { ...data, plan: newPlan },
    });
    moved++;
  }
  console.log(`Migrated ${moved} worker subscriptions. Customer subscriptions untouched.`);
}

main()
  .finally(() => prisma.$disconnect());
