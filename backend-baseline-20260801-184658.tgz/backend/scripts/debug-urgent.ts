// Focused urgent-matching debug — 2 logins only.
// Run: npx ts-node scripts/debug-urgent.ts
import { prisma } from '../src/config/prisma';

const BASE = 'http://localhost:5000/api/v1';
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

async function login(phone: string, role: string) {
  await sleep(65000);
  await fetch(`${BASE}/auth/send-otp`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone }) });
  const res = await fetch(`${BASE}/auth/verify-otp`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone, otp: '123456', role }) });
  const json = await res.json();
  return { token: json.data?.accessToken, user: json.data?.user };
}
const auth = (t: string) => ({ 'Content-Type': 'application/json', Authorization: `Bearer ${t}`, 'x-app-version': '2.0.0' });
async function api(method: string, path: string, token: string, body?: any) {
  const res = await fetch(BASE + path, { method, headers: auth(token), body: body ? JSON.stringify(body) : undefined });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, json };
}

async function main() {
  const amit = await login('+919876502005', 'CUSTOMER');  // Pune
  const arjun = await login('+919876501006', 'WORKER');   // Pune AC, urgent-eligible
  console.log('logins ok:', !!amit.token, !!arjun.token);

  const arjunDb = await prisma.workerProfile.findUnique({ where: { userId: arjun.user.id } });
  const amitAddr = await prisma.address.findFirst({ where: { userId: amit.user.id, isDefault: true } });
  console.log('Arjun profile:', JSON.stringify({ online: arjunDb?.isOnline, avail: arjunDb?.isAvailable, verified: arjunDb?.verificationStatus, urgent: arjunDb?.isUrgentEligible, cat: arjunDb?.category, lat: arjunDb?.latitude, lng: arjunDb?.longitude, radius: arjunDb?.serviceRadiusKm }));
  console.log('Amit addr:', JSON.stringify({ city: amitAddr?.city, lat: amitAddr?.latitude, lng: amitAddr?.longitude }));

  // Clear busy
  const cleared = await prisma.booking.updateMany({
    where: { workerId: arjun.user.id, status: { in: ['ACCEPTED', 'ON_THE_WAY', 'IN_PROGRESS'] } },
    data: { status: 'COMPLETED', completedAt: new Date() },
  });
  const busy = await prisma.booking.findMany({ where: { workerId: arjun.user.id, status: { in: ['ACCEPTED', 'ON_THE_WAY', 'IN_PROGRESS'] } }, select: { id: true } });
  console.log('cleared busy:', cleared.count, 'remaining active:', busy.length);

  // Now call urgent request
  const urgent = await api('POST', '/urgent/request', amit.token, { category: 'AC_TECHNICIAN', issueReason: 'AC not cooling', description: 'AC blowing warm air', pricingUnit: 'FLAT' });
  console.log('urgent request:', urgent.status, JSON.stringify(urgent.json));

  if (urgent.json.data?.requestId) {
    const boost = await api('POST', '/urgent/increase-offer', amit.token, { requestId: urgent.json.data.requestId, increaseAmount: 100 });
    console.log('boost:', boost.status, JSON.stringify(boost.json));
    const accept = await api('POST', '/urgent/accept', arjun.token, { requestId: urgent.json.data.requestId });
    console.log('accept:', accept.status, JSON.stringify(accept.json));
  }
  await prisma.$disconnect();
}
main().catch(e => { console.error('crash:', e); process.exit(1); });
