import 'dotenv/config';
import { readdirSync } from 'fs';
(async () => {
  const files = readdirSync('./src/routes').filter(f => f.endsWith('.routes.ts')).sort();
  for (const f of files) {
    const s = Date.now();
    try { await import('./src/routes/' + f); } catch (e: any) { console.log(f, 'ERROR', e.message); }
    console.log(f, Date.now() - s + 'ms');
  }
  process.exit(0);
})();
