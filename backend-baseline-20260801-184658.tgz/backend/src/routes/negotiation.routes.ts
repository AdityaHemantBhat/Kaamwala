import { Router } from 'express';
import { z } from 'zod';
import { authenticate } from '../middleware/auth.middleware';
import { validateRequest } from '../middleware/validate.middleware';
import { negotiationController } from '../controllers/negotiation.controller';

const router = Router();

router.get('/:bookingId', authenticate, negotiationController.getNegotiation);
router.post(
  '/:bookingId/make-offer',
  authenticate,
  validateRequest(z.object({
    body: z.object({
      amount: z.number().positive('Amount must be positive'),
      message: z.string().max(500).optional(),
    }),
  })),
  negotiationController.makeOffer,
);
router.post('/:bookingId/accept', authenticate, negotiationController.acceptOffer);
router.post('/:bookingId/reject', authenticate, negotiationController.rejectNegotiation);

export default router;
