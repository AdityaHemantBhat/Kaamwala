import { Router } from 'express';
import { z } from 'zod';
import { jobController } from '../controllers/job.controller';
import { authenticate } from '../middleware/auth.middleware';
import { requireRole } from '../middleware/role.middleware';
import { validateRequest } from '../middleware/validate.middleware';

const router = Router();

const createJobSchema = z.object({
  body: z.object({
    title: z.string().min(3, 'Title must be at least 3 characters').max(100),
    description: z.string().min(10, 'Description must be at least 10 characters').max(2000),
    category: z.enum([
      'PLUMBER', 'ELECTRICIAN', 'CARPENTER', 'MAID', 'DRIVER',
      'PAINTER', 'AC_TECHNICIAN', 'PEST_CONTROL', 'GARDENER',
      'COOK', 'TUTOR', 'SECURITY_GUARD'
    ]),
    price: z.number().positive('Price must be positive'),
    priceUnit: z.string().default('per visit'),
    city: z.string().optional(),
    pincode: z.string().optional(),
    estimatedHours: z.number().positive().optional(),
    skills: z.array(z.string()).optional(),
  }),
});

const updateJobSchema = z.object({
  body: z.object({
    title: z.string().min(3).max(100).optional(),
    description: z.string().min(10).max(2000).optional(),
    category: z.enum([
      'PLUMBER', 'ELECTRICIAN', 'CARPENTER', 'MAID', 'DRIVER',
      'PAINTER', 'AC_TECHNICIAN', 'PEST_CONTROL', 'GARDENER',
      'COOK', 'TUTOR', 'SECURITY_GUARD'
    ]).optional(),
    price: z.number().positive().optional(),
    priceUnit: z.string().optional(),
    city: z.string().optional(),
    pincode: z.string().optional(),
    estimatedHours: z.number().positive().optional(),
    skills: z.array(z.string()).optional(),
    status: z.enum(['ACTIVE', 'INACTIVE', 'COMPLETED']).optional(),
  }),
});

const statusUpdateSchema = z.object({
  body: z.object({
    status: z.enum(['ACTIVE', 'INACTIVE', 'COMPLETED']),
  }),
});

router.post('/', authenticate, requireRole('WORKER'), validateRequest(createJobSchema), jobController.createJob);
router.get('/', authenticate, requireRole('WORKER'), jobController.listJobs);
router.get('/:id', authenticate, requireRole('WORKER'), jobController.getJob);
router.put('/:id', authenticate, requireRole('WORKER'), validateRequest(updateJobSchema), jobController.updateJob);
router.delete('/:id', authenticate, requireRole('WORKER'), jobController.deleteJob);
router.patch('/:id/status', authenticate, requireRole('WORKER'), validateRequest(statusUpdateSchema), jobController.updateJobStatus);

export default router;
