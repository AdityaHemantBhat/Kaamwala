import { Router, Response } from 'express';
import { superAdminController } from '../controllers/super-admin.controller';
import { authenticate, AuthRequest } from '../middleware/auth.middleware';
import { sendError } from '../utils/response';

const router = Router();
const SUPER_ADMIN_PHONE = '+919999999999';

// Middleware: only super admin
const requireSuperAdmin = (req: AuthRequest, res: Response, next: Function) => {
  if (req.user?.phone !== SUPER_ADMIN_PHONE) {
    return sendError(res, 403, 'Super admin only');
  }
  next();
};

router.use(authenticate, requireSuperAdmin);

router.get('/admins', superAdminController.getAdmins);
router.post('/make-admin', superAdminController.makeAdmin);
router.post('/remove-admin', superAdminController.removeAdmin);
router.post('/ban', superAdminController.banUser);
router.post('/unban', superAdminController.unbanUser);
router.get('/audit-log', superAdminController.getAuditLog);
router.post('/broadcast', superAdminController.broadcast);

export default router;
