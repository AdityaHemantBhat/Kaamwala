import { Router } from 'express';
import { z } from 'zod';
import { authenticate } from '../middleware/auth.middleware';
import { requireRole } from '../middleware/role.middleware';
import { validateRequest } from '../middleware/validate.middleware';
import { requireMinVersion } from '../middleware/version.middleware';
import { requestsController } from '../controllers/requests.controller';

const router = Router();

const CATEGORY_ENUM = z.enum(['PLUMBER', 'ELECTRICIAN', 'CARPENTER', 'MAID', 'DRIVER', 'PAINTER', 'AC_TECHNICIAN', 'PEST_CONTROL', 'GARDENER', 'COOK', 'TUTOR', 'SECURITY_GUARD', 'NURSE', 'BABYSITTER']);

router.post(
  '/',
  authenticate, requireRole('CUSTOMER'), requireMinVersion(),
  validateRequest(z.object({
    body: z.object({
      title: z.string().min(5).max(100),
      description: z.string().min(10).max(2000),
      category: CATEGORY_ENUM,
      budget: z.number().positive().optional(),
      budgetType: z.enum(['fixed', 'negotiable', 'hourly']).default('negotiable'),
      pricingUnit: z.enum(['FLAT', 'PER_HOUR']).default('FLAT'),
      issueId: z.string().nullish(),       // null = 'Other' (Part 5)
      scope: z.any().nullish(),
      images: z.array(z.string().url()).max(6).optional(),
      addressId: z.string().nullish(),
      recommendationExposed: z.boolean().optional(),
      city: z.string().optional(),
      pincode: z.string().optional(),
      scheduledDate: z.string().optional(),
    }),
  })),
  requestsController.createRequest,
);

router.post(
  '/recommendation',
  authenticate, requireRole('CUSTOMER'), requireMinVersion(),
  validateRequest(z.object({
    body: z.object({
      category: CATEGORY_ENUM,
      pricingUnit: z.enum(['FLAT', 'PER_HOUR']).default('FLAT'),
      issueId: z.string().nullish(),
      scope: z.any().nullish(),
      addressId: z.string().nullish(),
      city: z.string().nullish(),
    }),
  })),
  requestsController.getRecommendation,
);

router.get('/', authenticate, requestsController.listMyRequests);
router.delete('/:id', authenticate, requestsController.deleteRequest);
router.get('/browse', authenticate, requireRole('WORKER'), requestsController.browseRequests);
router.get('/worker/accepted', authenticate, requireRole('WORKER'), requestsController.getAcceptedRequests);
router.post('/:id/quote', authenticate, requireRole('WORKER'), requireMinVersion(), requestsController.quoteOnRequest);
router.post('/:id/counter', authenticate, requireRole('CUSTOMER'), requireMinVersion(), requestsController.counterOffer);
router.get('/:id/offers', authenticate, requestsController.getOffers);
router.post('/:id/interest', authenticate, requireRole('WORKER'), requestsController.expressInterest);
router.get('/:id/interests', authenticate, requestsController.getInterests);
router.post('/:id/accept', authenticate, requireMinVersion(), requestsController.acceptInterest);
router.post('/:id/create-booking', authenticate, requireMinVersion(), requestsController.createBookingFromRequest);

export default router;
