import { createClient } from 'redis'
import { env } from './env'

export const redis = createClient({
  url: env.REDIS_URL,
})

redis.on('error', (err) => console.error('Redis Client Error', err))

// Connect asynchronously and export the promise or handle it in index.ts
export const connectRedis = async () => {
    await redis.connect()
}
