import { z } from 'zod';

const envSchema = z.object({
  PORT: z.string().default('5000'),
  DATABASE_URL: z.string().url(),
  REDIS_URL: z.string().url(),
  CLOUDINARY_CLOUD_NAME: z.string(),
  CLOUDINARY_API_KEY: z.string(),
  CLOUDINARY_API_SECRET: z.string(),
  GOOGLE_MAPS_API_KEY: z.string().optional(),
  FIREBASE_SERVICE_ACCOUNT_JSON: z.string(),
  TWILIO_ACCOUNT_SID: z.string(),
  TWILIO_AUTH_TOKEN: z.string(),
  TWILIO_PHONE_NUMBER: z.string(),
  CF_APP_ID: z.string(),
  CF_SECRET_KEY: z.string(),
  CF_PAYOUT_APP_ID: z.string().optional(),
  CF_PAYOUT_SECRET_KEY: z.string().optional(),
  CF_ENV: z.string().default('SANDBOX'),
  API_URL: z.string().default('http://localhost:5000'),
  JWT_ACCESS_EXPIRES_IN: z.string().default('15m'),
  JWT_REFRESH_EXPIRES_IN: z.string().default('7d'),
  PLATFORM_FEE_PERCENT: z.string().default('8'),
  LATE_CANCELLATION_FEE: z.string().default('50'),
});

export const env = envSchema.parse(process.env);