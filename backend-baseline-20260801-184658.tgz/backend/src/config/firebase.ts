import * as admin from 'firebase-admin';
import { env } from './env';
import { logger } from '../utils/logger';

let messagingInstance: admin.messaging.Messaging;

try {
  let serviceAccount = JSON.parse(env.FIREBASE_SERVICE_ACCOUNT_JSON);
  
  if (Object.keys(serviceAccount).length === 0 || !serviceAccount.private_key) {
      logger.warn('Firebase initialized with dummy config for local testing');
      // Do not use cert if private_key is missing, just don't initialize or use dummy app
      throw new Error('Missing private_key in Firebase Service Account');
  }

  // Handle cases where dotenv/JSON parsing leaves literal \n in the string
  serviceAccount.private_key = serviceAccount.private_key.replace(/\\n/g, '\n');

  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
  });
  messagingInstance = admin.messaging();
} catch (error: any) {
  logger.error(`Failed to initialize Firebase Admin SDK, push notifications will be disabled locally: ${error.message || error}`);
  // Mock the messaging instance for local dev
  messagingInstance = {
    send: async () => { logger.warn('Mock Firebase: message sent'); return 'mock-message-id'; },
    sendEach: async () => { return { responses: [], successCount: 0, failureCount: 0 }; },
    sendEachForMulticast: async () => { return { responses: [], successCount: 0, failureCount: 0 }; }
  } as unknown as admin.messaging.Messaging;
}

export const messaging = messagingInstance;
