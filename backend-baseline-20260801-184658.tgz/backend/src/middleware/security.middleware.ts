import { Request, Response, NextFunction } from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import { prisma } from '../config/prisma';
import { sendError } from '../utils/response';

export const ipBanMiddleware = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const ip = req.ip || req.socket.remoteAddress;
    
    if (!ip) {
      return next();
    }

    const bannedIp = await prisma.bannedIP.findUnique({
      where: { ip },
    });

    if (bannedIp) {
      // Check if temporary ban expired
      if (bannedIp.expiresAt && bannedIp.expiresAt < new Date()) {
        await prisma.bannedIP.delete({ where: { ip } });
        return next();
      }
      
      return sendError(res, 403, 'Your IP address has been banned from accessing this service.');
    }

    next();
  } catch (error) {
    console.error('IP Ban Middleware Error:', error);
    next();
  }
};

// Security Middleware
export const securityMiddleware = [
  helmet(),
  ipBanMiddleware,
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100, // limit per IP
    message: 'Too many requests, please try again later.'
  })
];

// Input Sanitization (Example for auth routes)
export const validateNoSqlInjection = (req: Request, res: Response, next: NextFunction) => {
    // Simple filter to prevent $where and $ne queries
    const sanitize = (obj: any) => {
        for (const key in obj) {
            if (typeof obj[key] === 'string' && (obj[key].includes('$') || obj[key].includes('{'))) {
                delete obj[key];
            }
        }
    };
    sanitize(req.body);
    sanitize(req.query);
    next();
};
