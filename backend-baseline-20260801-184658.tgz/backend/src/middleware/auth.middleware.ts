import { Request, Response, NextFunction } from 'express';
import { verifyAccessToken } from '../utils/crypto';
import { prisma } from '../config/prisma';
import { touchUserActivity } from '../utils/activity';

export interface AuthRequest extends Request {
  user?: {
    userId: string;
    role: string;
    phone: string;
  };
}

export const authenticate = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ success: false, message: 'Authentication required' });
    return;
  }

  let decoded: AuthRequest['user'];
  try {
    decoded = verifyAccessToken(authHeader.split(' ')[1]) as AuthRequest['user'];
  } catch {
    res.status(401).json({ success: false, message: 'Invalid or expired token' });
    return;
  }

  req.user = decoded!;

  try {
    const userDb = await prisma.user.findUnique({ where: { id: decoded!.userId } });

    if (!userDb) {
      res.status(401).json({ success: false, message: 'Invalid or expired token' });
      return;
    }

    if (userDb.isBanned) {
      if (userDb.banExpiresAt && userDb.banExpiresAt < new Date()) {
        // Ban expired — lift it and let the user through.
        await prisma.user.update({
          where: { id: userDb.id },
          data: { isBanned: false, banReason: null, banExpiresAt: null, bannedBy: null, bannedAt: null },
        });
      } else {
        res.status(403).json({ 
          success: false, 
          message: 'Your account is banned.',
          banned: {
            reason: userDb.banReason,
            expiresAt: userDb.banExpiresAt,
            type: userDb.banExpiresAt ? 'TEMPORARY' : 'PERMANENT'
          }
        });
        return;
      }
    }
  } catch {
    // A DB failure on the ban check must not hang the request (the old promise
    // chain never caught it) — fail open and let the request proceed.
  }

  touchUserActivity(decoded!.userId);
  next();
};
