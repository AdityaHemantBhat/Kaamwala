import { computeUrgentFinance } from '../services/workerPlans.service';

// Parts 60-69: urgent commission applies ONLY to the frozen base.
// FREE 15% / PRO 10% / ELITE 5%. Premium + boosts go 100% to the worker.

const BASE = 300;
const PREMIUM = 90; // 1.3x → 390 initial offer
const OFFER_390 = BASE + PREMIUM;

describe('Urgent Finance — commission on frozen base only (PART 67-69)', () => {
  test('FREE plan: 15% × base, premium kept by worker', () => {
    const f = computeUrgentFinance(BASE, OFFER_390, PREMIUM, 15);
    expect(f.commission).toBe(45);          // 15% × 300
    expect(f.customerBoost).toBe(0);
    expect(f.workerEarnings).toBe(345);     // 390 − 45
  });

  test('PRO plan: 10% × base', () => {
    const f = computeUrgentFinance(BASE, OFFER_390, PREMIUM, 10);
    expect(f.commission).toBe(30);
    expect(f.workerEarnings).toBe(360);
  });

  test('ELITE plan: 5% × base', () => {
    const f = computeUrgentFinance(BASE, OFFER_390, PREMIUM, 5);
    expect(f.commission).toBe(15);
    expect(f.workerEarnings).toBe(375);
  });

  test('100% of urgency premium goes to worker (not commissioned)', () => {
    // The premium is NOT part of the commission base: commission stays ₹45 for FREE
    const f = computeUrgentFinance(BASE, OFFER_390, PREMIUM, 15);
    expect(f.commission).toBe(45);
    expect(f.workerEarnings - (OFFER_390 - 45)).toBe(0);
  });

  test('customer boost is 100% to worker, still base-only commission (PART 69)', () => {
    const boosted = computeUrgentFinance(BASE, 500, PREMIUM, 15);
    expect(boosted.commission).toBe(45);        // 15% × base, not 15% × 500
    expect(boosted.customerBoost).toBe(110);    // 500 − 300 − 90
    expect(boosted.workerEarnings).toBe(455);   // 500 − 45
  });

  test('never commissions the boost — FREE/PRO/ELITE on boosted offer', () => {
    expect(computeUrgentFinance(BASE, 500, PREMIUM, 10).commission).toBe(30);
    expect(computeUrgentFinance(BASE, 500, PREMIUM, 10).workerEarnings).toBe(470);
    expect(computeUrgentFinance(BASE, 500, PREMIUM, 5).commission).toBe(15);
    expect(computeUrgentFinance(BASE, 500, PREMIUM, 5).workerEarnings).toBe(485);
  });

  test('rounding is deterministic — never fractional commission', () => {
    const f = computeUrgentFinance(333, 433, 100, 15);
    expect(f.commission).toBe(Math.round(333 * 0.15)); // 50, not 49.95
    expect(Number.isInteger(f.commission)).toBe(true);
  });

  test('boost cannot be negative (offer only moves up)', () => {
    const f = computeUrgentFinance(BASE, OFFER_390, PREMIUM, 15);
    expect(f.customerBoost).toBeGreaterThanOrEqual(0);
  });
});
