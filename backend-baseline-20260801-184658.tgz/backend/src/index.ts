import 'dotenv/config'; // Add this at the very top
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import http from 'http';
import { Server } from 'socket.io';
import { env } from './config/env';
import { logger } from './utils/logger';
import { prisma } from './config/prisma';
import { connectRedis } from './config/redis';
import { sanitizeStrings } from './middleware/sanitize.middleware';
import { apiLimiter } from './middleware/rateLimit.middleware';
import { ipBanMiddleware } from './middleware/security.middleware';
import { errorHandler } from './middleware/error.middleware';
import apiRoutes from './routes';

import { initSocket } from './services/socket.service';

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

initSocket(io);

app.use(helmet());
app.use(cors({ origin: ['http://localhost:8081', 'kaamwala://'] }));
app.use(morgan('dev'));
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ limit: '5mb', extended: true }));
app.use(sanitizeStrings);
app.use(ipBanMiddleware);

app.use('/api/v1', apiLimiter, apiRoutes);

app.use(errorHandler);

connectRedis().then(() => logger.info('Redis connected')).catch(err => logger.error(err));

server.listen(env.PORT, () => {
  logger.info(`Server running on port ${env.PORT}`);
});

// Subscription expiry checker
async function checkExpiredSubscriptions() {
  try {
    // Customer plans (BASIC/PLUS/PRO)
    const expired = await prisma.user.findMany({
      where: { isPremium: true, premiumExpiresAt: { lt: new Date() } },
    });
    for (const user of expired) {
      await prisma.user.update({
        where: { id: user.id },
        data: { isPremium: false, premiumPlan: 'BASIC', premiumExpiresAt: null },
      });
      await prisma.userSubscription.updateMany({
        where: { userId: user.id, status: 'active' },
        data: { plan: 'BASIC', status: 'expired' },
      });
    }

    // Worker plans (FREE/PRO/ELITE) — separate table (Part 60-69)
    const expiredWorkerSubs = await prisma.workerSubscription.findMany({
      where: { status: 'active', plan: { not: 'FREE' }, currentPeriodEnd: { lt: new Date() } },
    });
    for (const sub of expiredWorkerSubs) {
      await prisma.workerSubscription.update({
        where: { id: sub.id },
        data: { status: 'expired', plan: 'FREE', currentPeriodEnd: null },
      });
      if (sub.plan === 'ELITE') {
        await prisma.workerProfile.updateMany({
          where: { userId: sub.userId },
          data: { isGuaranteed: false, guaranteedSince: null },
        });
      }
    }
  } catch (e: any) { console.error(e.message); }
}
setInterval(checkExpiredSubscriptions, 60 * 60 * 1000);
checkExpiredSubscriptions();

// Production scheduled jobs: urgent expiry, orphan media cleanup, issue promotion
import { startScheduledJobs } from './services/scheduledJobs.service';
startScheduledJobs();

process.on('SIGTERM', async () => {
  await prisma.$disconnect();
  process.exit(0);
});

process.on('SIGINT', async () => {
  await prisma.$disconnect();
  process.exit(0);
});
