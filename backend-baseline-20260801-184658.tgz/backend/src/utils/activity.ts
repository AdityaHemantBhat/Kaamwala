import { prisma } from '../config/prisma';

// Throttle window: at most one lastActiveAt write per user within this window,
// so a busy user costs at most ~288 writes/day instead of one per request.
const WINDOW_MS = 5 * 60 * 1000;
const MAX_CACHE_SIZE = 10_000;

// Timestamp (ms) of the last write we issued for each user.
const lastTouch = new Map<string, number>();

/**
 * Fire-and-forget realtime "last seen" heartbeat. Never blocks or fails the
 * request it runs under — DB errors are swallowed, writes are throttled.
 */
export function touchUserActivity(userId: string): void {
  const now = Date.now();
  const last = lastTouch.get(userId) ?? 0;
  if (now - last < WINDOW_MS) return;

  // Reserve the slot immediately; the write below is idempotent so a lost race
  // between two concurrent requests is harmless.
  lastTouch.set(userId, now);

  prisma.user
    .update({ where: { id: userId }, data: { lastActiveAt: new Date() } })
    .then(() => {
      // Keep the cache bounded on long-lived servers.
      if (lastTouch.size > MAX_CACHE_SIZE) {
        const cutoff = now - WINDOW_MS * 4;
        for (const [key, value] of lastTouch) {
          if (value < cutoff) lastTouch.delete(key);
        }
      }
    })
    .catch(() => {
      // Best-effort only — the request that triggered this must not fail.
    });
}
