import fs from 'fs';
import path from 'path';
import jwt from 'jsonwebtoken';

const privateKey = fs.readFileSync(path.join(process.cwd(), 'keys/access.private.pem'));
const publicKey = fs.readFileSync(path.join(process.cwd(), 'keys/access.public.pem'));

export function signAccessToken(payload: object): string {
  return jwt.sign(payload, privateKey, { algorithm: 'RS256', expiresIn: '15m' });
}

export function verifyAccessToken(token: string): jwt.JwtPayload {
  return jwt.verify(token, publicKey, { algorithms: ['RS256'] }) as jwt.JwtPayload;
}
