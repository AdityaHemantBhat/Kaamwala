import { Response } from 'express';
import { prisma } from '../config/prisma';
import { sendResponse, sendError } from '../utils/response';
import { AuthRequest } from '../middleware/auth.middleware';

export const addressController = {
  getAddresses: async (req: AuthRequest, res: Response) => {
    try {
      const addresses = await prisma.address.findMany({
        where: { userId: req.user!.userId, isDeleted: false },
        orderBy: { createdAt: 'desc' },
      });
      sendResponse(res, 200, addresses);
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  createAddress: async (req: AuthRequest, res: Response) => {
    try {
      const data = req.body;

      if (data.isDefault) {
        await prisma.address.updateMany({
          where: { userId: req.user!.userId, isDefault: true },
          data: { isDefault: false },
        });
      }

      const address = await prisma.address.create({
        data: {
          ...data,
          userId: req.user!.userId,
          latitude: data.latitude ?? 0,
          longitude: data.longitude ?? 0,
        },
      });

      sendResponse(res, 201, address, 'Address added');
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  deleteAddress: async (req: AuthRequest, res: Response) => {
    try {
      const address = await prisma.address.findFirst({
        where: { id: req.params.id, userId: req.user!.userId, isDeleted: false },
      });

      if (!address) {
        return sendError(res, 404, 'Address not found');
      }

      await prisma.address.update({ where: { id: req.params.id }, data: { isDeleted: true, isDefault: false } });
      sendResponse(res, 200, null, 'Address deleted');
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  setDefault: async (req: AuthRequest, res: Response) => {
    try {
      const address = await prisma.address.findFirst({
        where: { id: req.params.id, userId: req.user!.userId, isDeleted: false },
      });

      if (!address) {
        return sendError(res, 404, 'Address not found');
      }

      await prisma.address.updateMany({
        where: { userId: req.user!.userId, isDefault: true },
        data: { isDefault: false },
      });

      const updated = await prisma.address.update({
        where: { id: req.params.id },
        data: { isDefault: true },
      });

      sendResponse(res, 200, updated, 'Default address updated');
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  }
};
