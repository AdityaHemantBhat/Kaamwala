import { Response } from 'express';
import { prisma } from '../config/prisma';
import { env } from '../config/env';
import { sendResponse, sendError } from '../utils/response';
import { AuthRequest } from '../middleware/auth.middleware';
import { emitToAdmins } from '../services/socket.service';

export const subscriptionController = {
  getPlans: (_req: any, res: Response) => {
    sendResponse(res, 200, [
      { id: 'BASIC', name: 'Basic', price: 0, priceLabel: 'Free', features: ['Standard worker search', 'Pay per booking', 'Email support'] },
      { id: 'PLUS', name: 'KaamWala Plus', price: 199, priceLabel: '₹199/month', features: ['10% discount on all bookings', 'Priority worker assignment', 'Free cancellation', 'Dedicated chat support'] },
      { id: 'PRO', name: 'KaamWala Pro', price: 499, priceLabel: '₹499/month', popular: true, features: ['20% discount on all bookings', 'Emergency booking included', 'Monthly AC + electrical checkup', 'Priority support 24/7', 'Free cancellation'] },
    ]);
  },

  getMySubscription: async (req: AuthRequest, res: Response) => {
    try {
      const sub = await prisma.userSubscription.findUnique({ where: { userId: req.user!.userId } });
      if (!sub || sub.plan === 'BASIC' || sub.status !== 'active') {
        return sendResponse(res, 200, { plan: 'BASIC', status: 'active' });
      }
      sendResponse(res, 200, { plan: sub.plan, status: sub.status, currentPeriodEnd: sub.currentPeriodEnd });
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  createOrder: async (req: AuthRequest, res: Response) => {
    try {
      const { plan } = req.body;
      if (!['PLUS', 'PRO'].includes(plan)) return sendError(res, 400, 'Invalid plan');

      const PLAN_MAP: Record<string, { price: number; label: string; discount: number }> = { PLUS: { price: 199, label: 'KaamWala Plus', discount: 10 }, PRO: { price: 499, label: 'KaamWala Pro', discount: 20 } };
      const details = PLAN_MAP[plan]!;
      const amount = details.price;

      const existing = await prisma.userSubscription.findUnique({ where: { userId: req.user!.userId } });
      if (existing && existing.plan === plan && existing.status === 'active') {
        return sendError(res, 400, 'Already subscribed');
      }

      const { Cashfree, CFEnvironment } = require('cashfree-pg');
      const cashfree = new Cashfree(
        env.CF_ENV === 'PRODUCTION' ? CFEnvironment.PRODUCTION : CFEnvironment.SANDBOX,
        env.CF_APP_ID, env.CF_SECRET_KEY,
      );
      const user = await prisma.user.findUnique({ where: { id: req.user!.userId } });
      const cfResponse = await cashfree.PGCreateOrder({
        order_amount: String(amount),
        order_currency: 'INR',
        customer_details: {
          customer_id: req.user!.userId,
          customer_name: user?.name || 'Customer',
          customer_email: user?.email || 'customer@kaamwala.app',
          customer_phone: user?.phone || '9999999999',
        },
      });
      const order = cfResponse.data;

      sendResponse(res, 201, {
        orderId: order.order_id,
        paymentSessionId: order.payment_session_id,
        amount: order.order_amount,
        currency: 'INR', plan,
        planDetails: details,
      });
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  verifyPayment: async (req: AuthRequest, res: Response) => {
    try {
      const { orderId, plan } = req.body;
      if (!orderId || !plan) return sendError(res, 400, 'Missing payment details');

      const periodEnd = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

      await prisma.userSubscription.upsert({
        where: { userId: req.user!.userId },
        update: { plan: plan as any, status: 'active', currentPeriodStart: new Date(), currentPeriodEnd: periodEnd },
        create: { userId: req.user!.userId, plan: plan as any, status: 'active', currentPeriodStart: new Date(), currentPeriodEnd: periodEnd },
      });

      await prisma.user.update({
        where: { id: req.user!.userId },
        data: { isPremium: true, premiumPlan: plan, premiumExpiresAt: periodEnd },
      });

      const PLAN_MAP: Record<string, { price: number; label: string; discount: number }> = { PLUS: { price: 199, label: 'KaamWala Plus', discount: 10 }, PRO: { price: 499, label: 'KaamWala Pro', discount: 20 } };
      const details = PLAN_MAP[plan]!;
      await prisma.transaction.create({
        data: { userId: req.user!.userId, type: 'SUBSCRIPTION_PAYMENT', amount: details.price, description: `${details.label} — 1 month`, status: 'completed', reference: orderId },
      });

      emitToAdmins('admin_refresh', { type: 'subscription_update' });
      sendResponse(res, 200, { plan, expiresAt: periodEnd }, `Successfully upgraded to ${plan}!`);
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  cancelSubscription: async (req: AuthRequest, res: Response) => {
    try {
      const sub = await prisma.userSubscription.findUnique({ where: { userId: req.user!.userId } });
      if (!sub || sub.plan === 'BASIC') return sendError(res, 400, 'No active subscription');

      await prisma.userSubscription.update({
        where: { userId: req.user!.userId },
        data: { plan: 'BASIC', status: 'cancelled', cancelledAt: new Date() },
      });

      await prisma.user.update({
        where: { id: req.user!.userId },
        data: { isPremium: false, premiumPlan: 'BASIC', premiumExpiresAt: null },
      });

      sendResponse(res, 200, null, 'Subscription cancelled');
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },
};
