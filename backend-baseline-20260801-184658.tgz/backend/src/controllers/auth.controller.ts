import { Request, Response } from 'express';
import { authService } from '../services/auth.service';
import { sendResponse, sendError } from '../utils/response';
import { prisma } from '../config/prisma';
import { pricingService } from '../services/pricing.service';

export const authController = {
  sendOtp: async (req: Request, res: Response) => {
    try {
      const { phone } = req.body;
      const result = await authService.sendOtp(phone);
      sendResponse(res, 200, result);
    } catch (error: any) {
      sendError(res, 400, error.message);
    }
  },

  verifyOtp: async (req: Request, res: Response) => {
    try {
      const { phone, otp, role, fcmToken, deviceInfo } = req.body;
      const data = await authService.verifyOtp(phone, otp, role, { fcmToken, deviceInfo });
      sendResponse(res, 200, data);
    } catch (error: any) {
      sendError(res, 401, error.message);
    }
  },

  refresh: async (req: Request, res: Response) => {
    try {
      const { refreshToken } = req.body;
      const tokens = await authService.refreshTokens(refreshToken);
      sendResponse(res, 200, tokens);
    } catch (error: any) {
      sendError(res, 401, error.message);
    }
  },

  logout: async (req: Request, res: Response) => {
    try {
      const { refreshToken } = req.body;
      const result = await authService.logout(refreshToken);
      sendResponse(res, 200, result);
    } catch (error: any) {
      sendError(res, 400, error.message);
    }
  },

  updateProfile: async (req: any, res: Response) => {
    try {
      const { name, photoUrl, role, avatarUrl: incomingAvatar, category, city, state, experienceYears, hourlyRate, upiId, bankAccountNumber, bankIfsc, bio, weeklyEarningsGoal } = req.body;

      const userData: any = {};
      if (name !== undefined) userData.name = name;
      if (photoUrl !== undefined) userData.avatarUrl = photoUrl;
      if (incomingAvatar !== undefined) userData.avatarUrl = incomingAvatar;
      if (role !== undefined) userData.role = role;

      const user = await prisma.user.update({
        where: { id: req.user.userId },
        data: userData,
        select: { id: true, name: true, phone: true, role: true, avatarUrl: true },
      });

      if (user.role === 'WORKER') {
        const workerData: any = {};
        if (category !== undefined) workerData.category = category;
        if (city !== undefined) workerData.city = city;
        if (state !== undefined) workerData.state = state;
        if (experienceYears !== undefined) workerData.experienceYears = Number(experienceYears);
        if (hourlyRate !== undefined) workerData.hourlyRate = Number(hourlyRate);
        if (upiId !== undefined) workerData.upiId = upiId;
        if (bankAccountNumber !== undefined) workerData.bankAccountNumber = bankAccountNumber;
        if (bankIfsc !== undefined) workerData.bankIfsc = bankIfsc;
        if (bio !== undefined) workerData.bio = bio;
        if (weeklyEarningsGoal !== undefined) workerData.weeklyEarningsGoal = Number(weeklyEarningsGoal);

        // Platform minimum-floor validation for worker rates (Part 48) — never trust frontend.
        if (workerData.hourlyRate !== undefined) {
          const existing = await prisma.workerProfile.findUnique({ where: { userId: user.id } });
          const rateCategory = workerData.category || existing?.category;
          const floorOk = await pricingService.validateMinimumFloor(rateCategory as any, workerData.hourlyRate, 'PER_HOUR');
          if (!floorOk) {
            const min = parseInt(await pricingService.getConfig('PLATFORM_MIN_HOURLY', '150'), 10);
            return sendError(res, 400, `Hourly rate cannot be below the platform minimum of ₹${min}/hr`);
          }
        }

        if (Object.keys(workerData).length > 0) {
          await prisma.workerProfile.upsert({
            where: { userId: user.id },
            update: workerData,
            create: { userId: user.id, category: 'PLUMBER', ...workerData },
          });
        }
      }

      sendResponse(res, 200, user, 'Profile updated');
    } catch (error: any) {
      sendError(res, 400, error.message);
    }
  }
};
