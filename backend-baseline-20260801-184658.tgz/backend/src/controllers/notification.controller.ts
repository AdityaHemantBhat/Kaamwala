import { Response } from 'express';
import { prisma } from '../config/prisma';
import { sendResponse, sendError } from '../utils/response';
import { AuthRequest } from '../middleware/auth.middleware';

export const notificationController = {
  getNotifications: async (req: AuthRequest, res: Response) => {
    try {
      const notifications = await prisma.notification.findMany({
        where: { userId: req.user!.userId },
        orderBy: { createdAt: 'desc' },
        take: 100,
      });

      sendResponse(res, 200, notifications);
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  markAsRead: async (req: AuthRequest, res: Response) => {
    try {
      await prisma.notification.updateMany({
        where: { id: req.params.id, userId: req.user!.userId },
        data: { isRead: true },
      });

      sendResponse(res, 200, null, 'Marked as read');
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  markAllAsRead: async (req: AuthRequest, res: Response) => {
    try {
      await prisma.notification.updateMany({
        where: { userId: req.user!.userId, isRead: false },
        data: { isRead: true },
      });

      sendResponse(res, 200, null, 'All marked as read');
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  registerPushToken: async (req: AuthRequest, res: Response) => {
    try {
      const { token, platform } = req.body;
      if (!token) return sendError(res, 400, 'Token required');

      await prisma.user.update({
        where: { id: req.user!.userId },
        data: { fcmToken: token },
      });

      sendResponse(res, 200, null, 'Push token registered');
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  }
};
