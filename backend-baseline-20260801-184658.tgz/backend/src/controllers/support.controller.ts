import { Response } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma';
import { sendResponse, sendError } from '../utils/response';
import { emitToUser, emitToAdmins } from '../services/socket.service';
import { AuthRequest } from '../middleware/auth.middleware';

const createTicketSchema = z.object({
  subject: z.string().min(3).max(200),
  description: z.string().min(10).max(5000),
  bookingId: z.string().optional(),
  priority: z.enum(['low', 'medium', 'high']).optional(),
});

const replySchema = z.object({
  message: z.string().min(1).max(5000),
  imageUrl: z.string().optional(),
});

export const supportController = {
  createTicket: async (req: AuthRequest, res: Response) => {
    try {
      const parsed = createTicketSchema.parse(req.body);
      const ticket = await prisma.supportTicket.create({
        data: { userId: req.user!.userId, subject: parsed.subject, description: parsed.description, bookingId: parsed.bookingId || undefined, priority: parsed.priority || 'medium', status: 'open' },
      });
      await prisma.ticketMessage.create({ data: { ticketId: ticket.id, senderId: req.user!.userId, message: parsed.description, isSystemMessage: true } });
      
      const admins = await prisma.user.findMany({ where: { role: 'ADMIN' }, select: { id: true } });
      for (const a of admins) { try { emitToUser(a.id, 'new_ticket', { ticketId: ticket.id, subject: parsed.subject }); } catch {} }
      
      emitToAdmins('admin_refresh', { type: 'ticket' });
      
      sendResponse(res, 201, ticket, 'Ticket created');
    } catch (e: any) { sendError(res, 400, e.message || 'Failed'); }
  },

  getUserTickets: async (req: AuthRequest, res: Response) => {
    try {
      const tickets = await prisma.supportTicket.findMany({
        where: { userId: req.user!.userId },
        include: { messages: { orderBy: { createdAt: 'asc' }, take: 1 } },
        orderBy: { updatedAt: 'desc' },
      });
      sendResponse(res, 200, tickets);
    } catch (e: any) { sendError(res, 500, e.message); }
  },

  getTicketDetails: async (req: AuthRequest, res: Response) => {
    try {
      const ticket = await prisma.supportTicket.findUnique({
        where: { id: req.params.id },
        include: { 
          messages: { orderBy: { createdAt: 'asc' }, include: { sender: { select: { name: true, role: true } } } },
          user: { select: { id: true, name: true, phone: true, role: true, subscription: { select: { plan: true } } } }
        },
      });
      if (!ticket) return sendError(res, 404, 'Ticket not found');
      if (ticket.userId !== req.user!.userId && req.user!.role !== 'ADMIN') return sendError(res, 403, 'Access denied');
      sendResponse(res, 200, ticket);
    } catch (e: any) { sendError(res, 500, e.message); }
  },

  replyToTicket: async (req: AuthRequest, res: Response) => {
    try {
      const parsed = replySchema.parse(req.body);
      const ticket = await prisma.supportTicket.findUnique({ where: { id: req.params.id } });
      if (!ticket) return sendError(res, 404, 'Ticket not found');
      if (ticket.userId !== req.user!.userId && req.user!.role !== 'ADMIN') return sendError(res, 403, 'Access denied');
      if (ticket.status === 'resolved' || ticket.status === 'closed') return sendError(res, 400, 'Ticket is closed');

      const msg = await prisma.ticketMessage.create({
        data: { ticketId: ticket.id, senderId: req.user!.userId, message: parsed.message, imageUrl: parsed.imageUrl || null, isFromAdmin: req.user!.role === 'ADMIN' },
        include: { sender: { select: { name: true, role: true } } },
      });

      if (req.user!.role === 'ADMIN') {
        if (ticket.status === 'open') {
          await prisma.supportTicket.update({ where: { id: ticket.id }, data: { status: 'in_progress' } });
        }
        try { emitToUser(ticket.userId, 'ticket_reply', { ticketId: ticket.id, message: parsed.message }); } catch {}
      } else {
        const admins = await prisma.user.findMany({ where: { role: 'ADMIN' }, select: { id: true } });
        for (const a of admins) { try { emitToUser(a.id, 'ticket_reply', { ticketId: ticket.id, message: parsed.message }); } catch {} }
        
        emitToAdmins('admin_refresh', { type: 'ticket' });
      }

      sendResponse(res, 201, msg, 'Reply sent');
    } catch (e: any) { sendError(res, 400, e.message); }
  },

  adminGetAll: async (req: AuthRequest, res: Response) => {
    try {
      const { status } = req.query;
      const where = {} as any;
      if (status) where.status = status;
      const tickets = await prisma.supportTicket.findMany({
        where,
        include: { user: { select: { id: true, name: true, phone: true, role: true } }, messages: { orderBy: { createdAt: 'desc' }, take: 1 } },
        orderBy: { updatedAt: 'desc' },
      });
      sendResponse(res, 200, tickets);
    } catch (e: any) { sendError(res, 500, e.message); }
  },

  adminUpdateStatus: async (req: AuthRequest, res: Response) => {
    try {
      const { status, adminReply } = req.body;
      const data: any = { status };
      if (status === 'resolved' || status === 'closed') data.resolvedAt = new Date();
      if (adminReply) data.adminReply = adminReply;
      const ticket = await prisma.supportTicket.update({ where: { id: req.params.id }, data });
      emitToAdmins('admin_refresh', { type: 'ticket' });
      sendResponse(res, 200, ticket, 'Status updated to ' + status);
    } catch (e: any) { sendError(res, 500, e.message); }
  }
};
