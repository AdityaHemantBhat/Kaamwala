import { Response } from 'express';
import { bookingService } from '../services/booking.service';
import { cancellationService } from '../services/cancellation.service';
import { sendResponse, sendError } from '../utils/response';
import { prisma } from '../config/prisma';
import { AuthRequest } from '../middleware/auth.middleware';
import { Twilio } from 'twilio';
import { env } from '../config/env';

const twilioClient = new Twilio(env.TWILIO_ACCOUNT_SID, env.TWILIO_AUTH_TOKEN);

const VALID_STATUSES = ['PENDING', 'NEGOTIATING', 'ACCEPTED', 'ON_THE_WAY', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED', 'DISPUTED'];

export const bookingController = {
  updateStatus: async (req: AuthRequest, res: Response) => {
    try {
      const { id } = req.params;
      const { status, otp, reasonCategory, cancelReason } = req.body;

      if (!status || !VALID_STATUSES.includes(status)) {
        return sendError(res, 400, `Invalid status. Must be one of: ${VALID_STATUSES.join(', ')}`);
      }

      if (status === 'CANCELLED') {
        const result = await cancellationService.initiateCancellation(id, req.user!.userId, req.user!.role, reasonCategory || 'OTHER', cancelReason);
        return sendResponse(res, 200, result, 'Cancellation initiated');
      }

      const booking = await bookingService.updateStatus(id, status, req.user!.userId, req.user!.role, otp);
      sendResponse(res, 200, booking, `Booking ${status.toLowerCase()}`);
    } catch (e: any) {
      const statusCode = e.message.includes('not found') ? 404
        : e.message.includes('Invalid') || e.message.includes('locked') || e.message.includes('cannot be cancelled') || e.message.includes('already') ? 400
        : 500;
      sendError(res, statusCode, e.message);
    }
  },

  confirmCancel: async (req: AuthRequest, res: Response) => {
    try {
      const { id } = req.params;
      if (req.user!.role !== 'CUSTOMER') return sendError(res, 403, 'Only customers can confirm cancellations');
      const result = await cancellationService.confirmCancellationRequest(id, req.user!.userId);
      sendResponse(res, 200, result, 'Cancellation confirmed');
    } catch (e: any) {
      sendError(res, 400, e.message);
    }
  },

  denyCancel: async (req: AuthRequest, res: Response) => {
    try {
      const { id } = req.params;
      if (req.user!.role !== 'CUSTOMER') return sendError(res, 403, 'Only customers can deny cancellations');
      const result = await cancellationService.denyCancellationRequest(id, req.user!.userId);
      sendResponse(res, 200, result, 'Cancellation denied');
    } catch (e: any) {
      sendError(res, 400, e.message);
    }
  },

  getBookings: async (req: AuthRequest, res: Response) => {
    try {
      const isWorker = req.user!.role === 'WORKER';
      const bookings = await prisma.booking.findMany({
        where: isWorker ? {
          OR: [
            { workerId: req.user!.userId },
            { status: 'PENDING' }
          ]
        } : { customerId: req.user!.userId },
        include: {
          review: { select: { id: true } },
          customer: {
            select: { id: true, name: true, avatarUrl: true, role: true }
          },
          worker: {
            select: { id: true, name: true, avatarUrl: true, role: true }
          },
          address: true
        },
        orderBy: { createdAt: 'desc' }
      });
      
      const bookingsWithReview = bookings.map((b: any) => ({
        ...b,
        hasReview: b.review !== null,
        review: undefined,
      }));
      sendResponse(res, 200, bookingsWithReview);
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  getActiveBooking: async (req: AuthRequest, res: Response) => {
    try {
      const isWorker = req.user!.role === 'WORKER';
      const activeBooking = await prisma.booking.findFirst({
        where: {
          ...(isWorker ? { workerId: req.user!.userId } : { customerId: req.user!.userId }),
          status: { in: ['ACCEPTED', 'ON_THE_WAY', 'IN_PROGRESS'] }
        },
        include: {
          customer: { select: { id: true, name: true, avatarUrl: true, role: true } },
          worker: { select: { id: true, name: true, avatarUrl: true, role: true } },
          address: true
        },
        orderBy: { updatedAt: 'desc' }
      });
      sendResponse(res, 200, activeBooking);
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  createBooking: async (req: AuthRequest, res: Response) => {
    try {
      const booking = await bookingService.createBooking(req.user!.userId, req.body);
      sendResponse(res, 201, booking);
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  getContactDetails: async (req: AuthRequest, res: Response) => {
    try {
      const { id } = req.params;
      const booking = await prisma.booking.findUnique({
        where: { id },
        include: { customer: true, worker: true }
      });

      if (!booking) return sendError(res, 404, 'Booking not found');

      const ALLOWED_STATES = ['ACCEPTED', 'ON_THE_WAY', 'IN_PROGRESS'];
      if (!ALLOWED_STATES.includes(booking.status)) {
        return sendError(res, 403, 'Contact details not available at this stage');
      }

      if (booking.customerId !== req.user!.userId && booking.workerId !== req.user!.userId) {
        return sendError(res, 403, 'Access denied');
      }

      const isWorker = req.user!.role === 'WORKER';
      const numberToReturn = isWorker ? booking.customer.phone : booking.worker?.phone;

      sendResponse(res, 200, { phone: numberToReturn });
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  getMessages: async (req: AuthRequest, res: Response) => {
    try {
      const { id } = req.params;
      const booking = await prisma.booking.findUnique({ where: { id } });

      if (!booking) return sendError(res, 404, 'Booking not found');
      if (booking.customerId !== req.user!.userId && booking.workerId !== req.user!.userId) {
        return sendError(res, 403, 'Access denied');
      }

      const chat = await prisma.chat.findUnique({
        where: { bookingId: id },
        include: {
          messages: {
            orderBy: { createdAt: 'asc' },
            include: { sender: { select: { name: true, role: true } } }
          }
        }
      });

      sendResponse(res, 200, chat ? chat.messages : []);
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  sendArrivalOtp: async (req: AuthRequest, res: Response) => {
    try {
      const { id } = req.params;
      const booking = await prisma.booking.findUnique({
        where: { id },
        include: { customer: true }
      });
      if (!booking || booking.workerId !== req.user!.userId) {
        return sendError(res, 403, 'Access denied');
      }
      if (!booking.arrivalOtp) {
        return sendError(res, 400, 'No arrival OTP generated yet');
      }

      try {
        await twilioClient.messages.create({
          body: `KaamWala: Your worker has arrived! Your secure 4-digit arrival code is ${booking.arrivalOtp}. Provide this to the worker to start the job.`,
          from: env.TWILIO_PHONE_NUMBER,
          to: booking.customer.phone,
        });
      } catch (e: any) {
        console.log('Twilio error, dev OTP is:', booking.arrivalOtp);
      }

      sendResponse(res, 200, { success: true }, 'OTP sent via SMS');
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  }
};
