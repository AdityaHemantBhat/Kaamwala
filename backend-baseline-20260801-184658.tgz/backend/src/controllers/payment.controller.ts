import { Response } from 'express';
import { prisma } from '../config/prisma';
import { paymentService } from '../services/payment.service';
import { bookingService } from '../services/booking.service';
import { cancellationService } from '../services/cancellation.service';
import { sendResponse, sendError } from '../utils/response';
import { AuthRequest } from '../middleware/auth.middleware';

export const paymentController = {
  createOrder: async (req: AuthRequest, res: Response) => {
    try {
      const order = await paymentService.createOrder(req.body.bookingId, req.body.amount, req.user!.userId);
      sendResponse(res, 200, order);
    } catch (e: any) {
      sendError(res, 500, e.message || 'Order creation failed');
    }
  },

  verifyPayment: async (req: AuthRequest, res: Response) => {
    try {
      const { bookingId, orderId, isMock } = req.body;

      if (isMock || (orderId && orderId.startsWith('mock_'))) {
        await prisma.booking.update({
          where: { id: bookingId },
          data: { paymentStatus: 'PAID', paymentRefId: orderId },
        });

        const booking = await prisma.booking.findUnique({
          where: { id: bookingId },
          select: { totalAmount: true, customerId: true },
        });

        await bookingService.processPayout(bookingId);

        if (booking) {
          await cancellationService.collectPendingFee(booking.customerId, bookingId, booking.totalAmount);
        }

        return sendResponse(res, 200, { success: true, mock: true });
      }

      await paymentService.verifyPayment(bookingId, orderId);
      await bookingService.processPayout(bookingId);

      const booking = await prisma.booking.findUnique({
        where: { id: bookingId },
        select: { totalAmount: true, customerId: true },
      });
      if (booking) {
        await cancellationService.collectPendingFee(booking.customerId, bookingId, booking.totalAmount);
      }

      sendResponse(res, 200, { success: true });
    } catch (e: any) {
      sendError(res, 500, e.message || 'Verification failed');
    }
  },

  payViaWallet: async (req: AuthRequest, res: Response) => {
    try {
      const { bookingId, amount } = req.body;
      const userId = req.user!.userId;

      if (!bookingId || !amount) {
        return sendError(res, 400, 'Booking ID and amount are required');
      }

      // Check if booking exists and belongs to the customer
      const booking = await prisma.booking.findUnique({
        where: { id: bookingId },
        select: { id: true, customerId: true, paymentStatus: true, totalAmount: true }
      });

      if (!booking) return sendError(res, 404, 'Booking not found');
      if (booking.customerId !== userId) return sendError(res, 403, 'Unauthorized');
      if (booking.paymentStatus === 'PAID') return sendError(res, 400, 'Booking is already paid');
      if (booking.totalAmount !== amount) return sendError(res, 400, 'Payment amount does not match booking total');

      // Check customer wallet balance
      const customer = await prisma.customerProfile.findUnique({
        where: { userId }
      });

      if (!customer) return sendError(res, 404, 'Customer profile not found');
      if (customer.walletBalance < amount) return sendError(res, 400, 'Insufficient wallet balance');

      // Perform transaction
      await prisma.$transaction(async (tx) => {
        // Deduct from wallet
        await tx.customerProfile.update({
          where: { userId },
          data: { walletBalance: { decrement: amount } }
        });

        // Record transaction
        await tx.transaction.create({
          data: {
            userId,
            type: 'BOOKING_PAYMENT',
            amount: -amount,
            description: `Payment for booking ${bookingId.slice(-6)} via Wallet`,
            status: 'completed',
            reference: bookingId
          }
        });

        // Update booking status
        await tx.booking.update({
          where: { id: bookingId },
          data: { 
            paymentStatus: 'PAID', 
            paymentRefId: `WALLET_${Date.now()}` 
          }
        });
      });

      // Process worker payout and fee collection outside transaction
      await bookingService.processPayout(bookingId);
      await cancellationService.collectPendingFee(userId, bookingId, booking.totalAmount);

      sendResponse(res, 200, { success: true });
    } catch (e: any) {
      sendError(res, 500, e.message || 'Wallet payment failed');
    }
  },

  callback: async (req: any, res: Response) => {
    const { order_id } = req.query;
    if (order_id) {
      res.redirect(`kaamwala://payment/success?order_id=${order_id}`);
    } else {
      res.redirect('kaamwala://payment/failed');
    }
  },

  getTransactions: async (req: AuthRequest, res: Response) => {
    try {
      const transactions = await prisma.transaction.findMany({
        where: { userId: req.user!.userId },
        orderBy: { createdAt: 'desc' },
        take: 50,
      });
      sendResponse(res, 200, transactions);
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  addMoney: async (req: AuthRequest, res: Response) => {
    try {
      const { amount } = req.body;
      if (!amount || amount < 1) return sendError(res, 400, 'Invalid amount');

      const userId = req.user!.userId;
      const orderIdStr = `wallet_topup_${userId}_${Date.now()}`;
      
      const order = await paymentService.createOrder(orderIdStr, amount, userId);
      sendResponse(res, 200, order);
    } catch (e: any) {
      sendError(res, 500, e.message || 'Failed to create topup order');
    }
  },

  verifyWalletTopup: async (req: AuthRequest, res: Response) => {
    try {
      const { orderId, isMock, amount: requestedAmount } = req.body;
      if (!orderId) return sendError(res, 400, 'orderId is required');

      const userId = req.user!.userId;

      // Check if transaction already exists for this orderId to prevent double crediting
      const existingTxn = await prisma.transaction.findFirst({
        where: { reference: orderId }
      });

      if (existingTxn) {
        return sendError(res, 400, 'This payment has already been processed');
      }

      // Verify payment with Cashfree. The mock path (Expo Go dev testing, where
      // the native SDK can't run) credits the client-declared amount; the real
      // path trusts only Cashfree's order status + amount.
      let amount: number;
      if (isMock) {
        amount = Number(requestedAmount);
        if (!amount || amount < 1) return sendError(res, 400, 'Invalid amount');
      } else {
        const verified = await paymentService.verifyWalletOrder(orderId);
        amount = Number(verified.amount);
      }
      let walletBalance = 0;

      // Update balance
      const worker = await prisma.workerProfile.findUnique({ where: { userId } });
      if (worker) {
        const newBalance = (worker.walletBalance || 0) + amount;
        const isFrozenUpdate = newBalance >= 0 && worker.isFrozen ? { isFrozen: false } : {};

        const updated = await prisma.workerProfile.update({
          where: { userId },
          data: { 
            walletBalance: { increment: amount },
            ...isFrozenUpdate
          },
        });
        walletBalance = updated.walletBalance;
      } else {
        const customer = await prisma.customerProfile.findUnique({ where: { userId } });
        if (customer) {
          const updated = await prisma.customerProfile.update({
            where: { userId },
            data: { walletBalance: { increment: amount } },
          });
          walletBalance = updated.walletBalance;
        } else {
          return sendError(res, 404, 'Profile not found');
        }
      }

      await prisma.transaction.create({
        data: { 
          userId, 
          type: 'WALLET_CREDIT', 
          amount, 
          description: 'Added money to wallet', 
          status: 'completed',
          reference: orderId
        },
      });

      sendResponse(res, 200, { success: true, walletBalance });
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  withdraw: async (req: AuthRequest, res: Response) => {
    try {
      const { amount, method = 'UPI', upiId, bankAccount, ifscCode, bankName, accountHolderName } = req.body;
      if (!amount || amount < 1) return sendError(res, 400, 'Invalid amount');
      
      let description = '';
      if (method === 'UPI') {
        if (!upiId) return sendError(res, 400, 'UPI ID required');
        description = `Withdrawal to UPI ${upiId}`;
      } else if (method === 'BANK') {
        if (!bankAccount || !ifscCode || !bankName || !accountHolderName) {
          return sendError(res, 400, 'Complete bank details required');
        }
        description = `Withdrawal to Bank ${bankName} (${bankAccount})`;
      } else {
        return sendError(res, 400, 'Invalid withdrawal method');
      }

      const userId = req.user!.userId;
      let walletBalance = 0;

      const worker = await prisma.workerProfile.findUnique({ where: { userId } });
      if (worker) {
        if ((worker.walletBalance || 0) < amount) return sendError(res, 400, 'Insufficient balance');
        const updated = await prisma.workerProfile.update({
          where: { userId },
          data: { walletBalance: { decrement: amount } },
        });
        walletBalance = updated.walletBalance;
      } else {
        const customer = await prisma.customerProfile.findUnique({ where: { userId } });
        if (customer) {
          if ((customer.walletBalance || 0) < amount) return sendError(res, 400, 'Insufficient balance');
          const updated = await prisma.customerProfile.update({
            where: { userId },
            data: { walletBalance: { decrement: amount } },
          });
          walletBalance = updated.walletBalance;
        } else {
          return sendError(res, 404, 'Profile not found');
        }
      }

      await prisma.transaction.create({
        data: { userId, type: 'WALLET_WITHDRAWAL', amount: -amount, description, status: 'completed' },
      });

      sendResponse(res, 200, { walletBalance });
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  }
};
