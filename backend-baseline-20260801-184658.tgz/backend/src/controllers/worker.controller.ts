import { Request, Response } from 'express';
import { workerService } from '../services/worker.service';
import { sendResponse, sendError } from '../utils/response';
import { prisma } from '../config/prisma';
import { AuthRequest } from '../middleware/auth.middleware';

export const workerController = {
  getWorkers: async (req: Request, res: Response) => {
    try {
      const workers = await prisma.workerProfile.findMany({
        include: {
          user: {
            select: { id: true, name: true, avatarUrl: true, role: true }
          },
          services: true
        }
      });
      sendResponse(res, 200, workers);
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  getStats: async (req: AuthRequest, res: Response) => {
    try {
      const workerProfile = await prisma.workerProfile.findUnique({
        where: { userId: req.user!.userId }
      });
      if (!workerProfile) return sendResponse(res, 200, {});

      const totalBookings = await prisma.booking.count({ where: { workerId: req.user!.userId } });
      const acceptedBookings = await prisma.booking.count({
        where: { workerId: req.user!.userId, status: { in: ['ACCEPTED', 'ON_THE_WAY', 'IN_PROGRESS', 'COMPLETED'] } },
      });
      const acceptanceRate = totalBookings > 0 ? Math.round((acceptedBookings / totalBookings) * 100) : 0;

      const recentAccepts = await prisma.booking.findMany({
        where: { workerId: req.user!.userId, acceptedAt: { not: null } },
        select: { createdAt: true, acceptedAt: true },
        take: 10,
        orderBy: { acceptedAt: 'desc' },
      });
      let avgResponseMin = 0;
      if (recentAccepts.length > 0) {
        const diffs = recentAccepts
          .map(b => (b.acceptedAt!.getTime() - b.createdAt.getTime()) / 60000)
          .filter(d => d > 0 && d < 120);
        if (diffs.length > 0) {
          avgResponseMin = Math.round(diffs.reduce((a, b) => a + b, 0) / diffs.length);
        }
      }

      let cityRank = 1;
      let cityPercentile = 5;
      let openRequestsCount = 0;
      
      if (workerProfile.city) {
        const cityWorkers = await prisma.workerProfile.findMany({
          where: { city: workerProfile.city, isBanned: false },
          select: { id: true, totalEarned: true },
          orderBy: { totalEarned: 'desc' }
        });
        
        const rankIndex = cityWorkers.findIndex((w: any) => w.id === workerProfile.id);
        if (rankIndex !== -1) {
          cityRank = rankIndex + 1;
          cityPercentile = Math.max(1, Math.ceil((cityRank / Math.max(1, cityWorkers.length)) * 100));
        }

        if (workerProfile.category) {
          openRequestsCount = await prisma.customerJobRequest.count({
            where: { 
              city: workerProfile.city,
              category: workerProfile.category,
              status: 'OPEN'
            }
          });
        }
      }

      sendResponse(res, 200, { ...workerProfile, acceptanceRate, responseTimeMinutes: avgResponseMin, cityRank, cityPercentile, openRequestsCount });
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  setOnlineStatus: async (req: AuthRequest, res: Response) => {
    try {
      const { isAvailable, lat, lng } = req.body;
      const payload: any = {
        isAvailable: Boolean(isAvailable),
        isOnline: Boolean(isAvailable),
        updatedAt: new Date(),
      };

      if (lat !== undefined && lng !== undefined) {
        const parsedLat = parseFloat(lat as any);
        const parsedLng = parseFloat(lng as any);
        if (!isNaN(parsedLat) && !isNaN(parsedLng)) {
          payload.latitude = parsedLat;
          payload.longitude = parsedLng;
          payload.lastLocationAt = new Date();
        }
      }

      const updated = await prisma.workerProfile.update({
        where: { userId: req.user!.userId },
        data: payload,
      });

      sendResponse(res, 200, updated);
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  searchWorkers: async (req: Request, res: Response) => {
    try {
      const { lat, lng, category, radius, minRating, maxPrice, page, limit, search } = req.query;
      const workers = await workerService.searchWorkers(
        parseFloat(lat as string),
        parseFloat(lng as string),
        category as any,
        minRating ? parseFloat(minRating as string) : undefined,
        maxPrice ? parseFloat(maxPrice as string) : undefined,
        radius ? parseInt(radius as string) : undefined,
        page ? parseInt(page as string) : 1,
        limit ? parseInt(limit as string) : 20,
        search as string | undefined
      );
      sendResponse(res, 200, workers);
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  getVerificationStatus: async (req: AuthRequest, res: Response) => {
    try {
      const profile = await prisma.workerProfile.findUnique({
        where: { userId: req.user!.userId },
        select: { verificationStatus: true, verificationNote: true, verifiedAt: true, idProofType: true, idProofUrl: true, selfieUrl: true },
      });
      if (!profile) return sendError(res, 404, 'Worker profile not found');
      sendResponse(res, 200, profile);
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  requestVerification: async (_req: AuthRequest, res: Response) => {
    // Deprecated (Part 45): the old endpoint accepted arbitrary client URLs and
    // set PENDING with no documents/consent. Use the guided flow:
    // GET /workers/verification/config → POST /start → /documents → /submit.
    return sendError(res, 410, 'Verification flow updated. Please use the guided verification flow in the app.');
  },

  appealBan: async (req: AuthRequest, res: Response) => {
    try {
      const profile = await prisma.workerProfile.findUnique({ where: { userId: req.user!.userId } });
      if (!profile) return sendError(res, 404, 'Worker profile not found');
      if (!profile.isBanned) return sendError(res, 400, 'Account is not banned');
      if (profile.isPermanentlyBanned) return sendError(res, 403, 'Permanent ban. Cannot appeal.');

      const existing = await prisma.supportTicket.findFirst({
        where: { userId: req.user!.userId, subject: 'Ban Appeal', status: { in: ['open', 'in_progress'] } },
      });
      if (existing) return sendError(res, 400, 'You already have an open appeal. Please wait for admin response.');

      const ticket = await prisma.supportTicket.create({
        data: {
          userId: req.user!.userId,
          subject: 'Ban Appeal',
          description: req.body.reason || 'I would like to appeal my ban. Please review.',
          priority: 'high',
          status: 'open',
        },
      });

      await prisma.ticketMessage.create({
        data: {
          ticketId: ticket.id,
          senderId: req.user!.userId,
          message: 'BAN APPEAL: ' + (req.body.reason || 'Worker is appealing their ban. Please review audit logs.'),
          isSystemMessage: true,
        },
      });

      try {
        const { emitToUser } = await import('../services/socket.service');
        const admins = await prisma.user.findMany({ where: { role: 'ADMIN' }, select: { id: true } });
        for (const a of admins) {
          try { emitToUser(a.id, 'ban_appeal', { userId: req.user!.userId, ticketId: ticket.id, name: (req.user as any)?.name || 'Worker' }); } catch {}
        }
      } catch {}

      sendResponse(res, 201, { ticketId: ticket.id }, 'Appeal submitted. An admin will review your case and respond in the support chat.');
    } catch (e: any) { sendError(res, 500, e.message); }
  },

  getBanStatus: async (req: AuthRequest, res: Response) => {
    try {
      const profile = await prisma.workerProfile.findUnique({
        where: { userId: req.user!.userId },
        select: { isBanned: true, isPermanentlyBanned: true, isFrozen: true, walletBalance: true, banReason: true, bannedAt: true, appealCount: true },
      });
      sendResponse(res, 200, profile || {});
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  getWorkerById: async (req: Request, res: Response) => {
    try {
      const worker = await prisma.workerProfile.findUnique({
        where: { userId: req.params.userId },
        include: {
          user: { select: { name: true, avatarUrl: true, phone: true } },
          services: true,
        },
      });
      if (!worker) return sendError(res, 404, 'Worker not found');

      const photos = await prisma.jobPhoto.findMany({
        where: { workerProfileId: worker.id, isPublic: true },
        orderBy: { createdAt: 'desc' },
        take: 10,
      });

      sendResponse(res, 200, { ...worker, photos });
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  }
};
