import { Response } from 'express';
import { prisma } from '../config/prisma';
import { sendResponse, sendError } from '../utils/response';
import { createAuditLog } from '../utils/audit';
import { AuthRequest } from '../middleware/auth.middleware';

const SUPER_ADMIN_PHONE = '+919999999999';

export const superAdminController = {
  getAdmins: async (req: AuthRequest, res: Response) => {
    try {
      const admins = await prisma.user.findMany({
        where: { role: 'ADMIN' },
        select: { id: true, name: true, phone: true, isActive: true, isBanned: true, createdAt: true, lastActiveAt: true, loginCount: true },
        orderBy: { createdAt: 'desc' },
      });
      sendResponse(res, 200, admins);
    } catch (e: any) { sendError(res, 500, e.message); }
  },

  makeAdmin: async (req: AuthRequest, res: Response) => {
    try {
      const { phone, name } = req.body;
      if (!phone) return sendError(res, 400, 'Phone required');
      if (phone === SUPER_ADMIN_PHONE) return sendError(res, 400, 'Cannot modify super admin');

      let user = await prisma.user.findUnique({ where: { phone } });
      if (!user) {
        user = await prisma.user.create({
          data: { phone, name: name || 'Admin', role: 'ADMIN' },
        });
      } else {
        user = await prisma.user.update({
          where: { phone },
          data: { role: 'ADMIN', name: name || user.name },
        });
      }

      await createAuditLog(prisma, req, {
        userId: req.user!.userId, action: 'admin.promoted', resource: 'User', resourceId: user.id, newValue: { role: 'ADMIN' },
      });

      sendResponse(res, 200, { id: user.id, name: user.name, phone: user.phone }, 'Admin created');
    } catch (e: any) { sendError(res, 500, e.message); }
  },

  removeAdmin: async (req: AuthRequest, res: Response) => {
    try {
      const { userId } = req.body;
      if (!userId) return sendError(res, 400, 'userId required');

      const target = await prisma.user.findUnique({ where: { id: userId } });
      if (!target || target.role !== 'ADMIN') return sendError(res, 400, 'Not an admin');
      if (target.phone === SUPER_ADMIN_PHONE) return sendError(res, 400, 'Cannot modify super admin');

      await prisma.user.update({ where: { id: userId }, data: { role: 'CUSTOMER' } });

      await createAuditLog(prisma, req, {
        userId: req.user!.userId, action: 'admin.demoted', resource: 'User', resourceId: userId,
      });

      sendResponse(res, 200, null, 'Admin removed');
    } catch (e: any) { sendError(res, 500, e.message); }
  },

  banUser: async (req: AuthRequest, res: Response) => {
    try {
      const { userId, reason } = req.body;
      if (!userId) return sendError(res, 400, 'userId required');

      const target = await prisma.user.findUnique({ where: { id: userId } });
      if (!target) return sendError(res, 404, 'User not found');
      if (target.phone === SUPER_ADMIN_PHONE) return sendError(res, 400, 'Cannot ban super admin');

      await prisma.user.update({
        where: { id: userId },
        data: { isBanned: true, banReason: reason || 'Banned by admin', bannedAt: new Date(), bannedBy: req.user!.userId },
      });

      await createAuditLog(prisma, req, {
        userId: req.user!.userId, action: 'user.banned', resource: 'User', resourceId: userId, newValue: { banned: true, reason },
      });

      sendResponse(res, 200, null, 'User banned');
    } catch (e: any) { sendError(res, 500, e.message); }
  },

  unbanUser: async (req: AuthRequest, res: Response) => {
    try {
      const { userId } = req.body;
      if (!userId) return sendError(res, 400, 'userId required');

      await prisma.user.update({
        where: { id: userId },
        data: { isBanned: false, banReason: null, bannedAt: null, bannedBy: null },
      });

      await createAuditLog(prisma, req, {
        userId: req.user!.userId, action: 'user.unbanned', resource: 'User', resourceId: userId,
      });

      sendResponse(res, 200, null, 'User unbanned');
    } catch (e: any) { sendError(res, 500, e.message); }
  },

  getAuditLog: async (req: AuthRequest, res: Response) => {
    try {
      const logs = await prisma.auditLog.findMany({
        select: { id: true, action: true, resource: true, resourceId: true, ip: true, userAgent: true, createdAt: true, user: { select: { name: true } } },
        orderBy: { createdAt: 'desc' },
        take: 50,
      });
      sendResponse(res, 200, logs);
    } catch (e: any) { sendError(res, 500, e.message); }
  },

  broadcast: async (req: AuthRequest, res: Response) => {
    try {
      const { title, body } = req.body;
      if (!title || !body) return sendError(res, 400, 'Title and body required');

      const users = await prisma.user.findMany({ select: { id: true }, take: 1000 });

      await prisma.notification.createMany({
        data: users.map(u => ({ userId: u.id, title, body, type: 'broadcast' })),
      });

      sendResponse(res, 200, { sent: users.length }, `Broadcast sent to ${users.length} users`);
    } catch (e: any) { sendError(res, 500, e.message); }
  }
};
