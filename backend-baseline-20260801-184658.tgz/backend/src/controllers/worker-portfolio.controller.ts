import { Response } from 'express';
import { prisma } from '../config/prisma';
import { sendResponse, sendError } from '../utils/response';
import { AuthRequest } from '../middleware/auth.middleware';

export const workerPortfolioController = {
  getPhotos: async (req: AuthRequest, res: Response) => {
    try {
      const workerProfile = await prisma.workerProfile.findUnique({
        where: { userId: req.user!.userId },
        select: { id: true },
      });
      if (!workerProfile) return sendError(res, 404, 'Worker profile not found');

      const photos = await prisma.jobPhoto.findMany({
        where: { workerProfileId: workerProfile.id, isPublic: true },
        orderBy: { createdAt: 'desc' },
      });

      sendResponse(res, 200, photos);
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  addPhoto: async (req: AuthRequest, res: Response) => {
    try {
      const workerProfile = await prisma.workerProfile.findUnique({
        where: { userId: req.user!.userId },
        select: { id: true },
      });
      if (!workerProfile) return sendError(res, 404, 'Worker profile not found');

      const { beforeUrl, afterUrl, caption, bookingId } = req.body;
      if (!beforeUrl || !afterUrl) return sendError(res, 400, 'Both before and after URLs required');

      const photo = await prisma.jobPhoto.create({
        data: {
          workerProfileId: workerProfile.id,
          beforeUrl, afterUrl, caption, bookingId, isPublic: true,
        },
      });

      sendResponse(res, 201, photo, 'Portfolio photo added');
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },
};
