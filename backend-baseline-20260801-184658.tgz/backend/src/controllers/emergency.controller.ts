import { Response } from 'express';
import { prisma } from '../config/prisma';
import { sendResponse, sendError } from '../utils/response';
import { generateBookingNumber } from '../utils/booking-number';
import { AuthRequest } from '../middleware/auth.middleware';
import { emitToAdmins } from '../services/socket.service';

export const emergencyController = {
  getWorkers: async (req: AuthRequest, res: Response) => {
    try {
      const { category, lat, lng, city } = req.query;
      if (!category) return sendError(res, 400, 'Category required');

      const workers = await prisma.workerProfile.findMany({
        where: {
          category: category as any,
          isAvailable: true,
          isFrozen: false,
          isOnline: true,
          isUrgentEligible: true,
          verificationStatus: 'VERIFIED',
          city: city as string | undefined,
        },
        include: { user: { select: { name: true } } },
        take: 5,
      });

      const scored = workers
        .map(w => {
          let dist = 9999;
          if (lat && lng && w.latitude && w.longitude) {
            const dLat = (w.latitude - parseFloat(lat as string)) * Math.PI / 180;
            const dLng = (w.longitude - parseFloat(lng as string)) * Math.PI / 180;
            const a = Math.sin(dLat/2)**2 + Math.cos(parseFloat(lat as string) * Math.PI/180) * Math.cos(w.latitude * Math.PI/180) * Math.sin(dLng/2)**2;
            dist = 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
          }
          const score = (w.rating / 5) * 50 + Math.max(0, 50 - dist * 5);
          return { ...w, distanceKm: Math.round(dist * 10) / 10, score: Math.round(score) };
        })
        .filter(w => w.distanceKm <= 5)
        .sort((a, b) => b.score - a.score);

      sendResponse(res, 200, {
        workers: scored,
        urgentSurgeMultiplier: 1.5,
        note: 'Urgent bookings have 1.5x surge pricing. Worker dispatched within 60 min.',
      });
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  bookEmergency: async (req: AuthRequest, res: Response) => {
    try {
      const { workerId, serviceCategory, description, addressId } = req.body;
      if (!workerId || !serviceCategory || !addressId) {
        return sendError(res, 400, 'Missing required fields: workerId, serviceCategory, addressId');
      }

      const worker = await prisma.workerProfile.findUnique({ where: { userId: workerId } });
      if (!worker || !worker.isUrgentEligible) {
        return sendError(res, 400, 'Worker not available for urgent booking');
      }

      const baseAmount = worker.hourlyRate * 1.5;
      const platformFee = Math.round(baseAmount * 0.15);
      const totalAmount = baseAmount + platformFee;

      const booking = await prisma.booking.create({
        data: {
          bookingNumber: generateBookingNumber(),
          type: 'URGENT',
          customerId: req.user!.userId,
          workerId,
          addressId,
          serviceCategory: serviceCategory as any,
          serviceName: `URGENT: ${serviceCategory.replace(/_/g, ' ')}`,
          description: description || 'Urgent service requested',
          scheduledAt: new Date(Date.now() + 1800000), // 30 min
          estimatedDuration: 120,
          status: 'PENDING',
          isSurge: true,
          surgeMultiplier: 1.5,
          baseAmount,
          platformFee,
          workerEarnings: baseAmount - platformFee,
          totalAmount,
        },
      });

      sendResponse(res, 201, booking, 'Urgent booking created! Worker will be dispatched shortly.');
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  },

  handleSOS: async (req: AuthRequest, res: Response) => {
    try {
      const { lat, lng, bookingId, type } = req.body;
      const userId = req.user!.userId;
      
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { name: true, phone: true }
      });

      // 1. Create a support ticket automatically
      const ticket = await prisma.supportTicket.create({
        data: {
          userId,
          subject: `URGENT SOS ALERT: ${user?.name || 'Worker'}`,
          description: `SOS Alert triggered by worker.`,
          status: 'open',
          messages: {
            create: {
              senderId: userId,
              message: `SOS Triggered! Location: Lat ${lat}, Lng ${lng}. ${bookingId ? 'Booking ID: ' + bookingId : ''}`,
            }
          }
        },
        include: { messages: true }
      });

      // 2. Alert all admins immediately via Socket
      emitToAdmins('admin_alert', {
        title: '🔴 SOS ALERT',
        message: `${user?.name} triggered SOS!`,
        ticketId: ticket.id,
        lat,
        lng,
        userId
      });

      sendResponse(res, 200, { ticketId: ticket.id }, 'SOS Alert Sent');
    } catch (e: any) {
      sendError(res, 500, e.message);
    }
  }
};
