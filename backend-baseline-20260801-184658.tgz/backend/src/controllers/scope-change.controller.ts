import { Response } from 'express';
import { prisma } from '../config/prisma';
import { AuthRequest } from '../middleware/auth.middleware';
import { sendResponse, sendError } from '../utils/response';
import { emitToUser, emitToBooking } from '../services/socket.service';
import { notificationService } from '../services/notification.service';

// Scope / Change-Orders (PART 16)
// Worker proposes a change; customer MUST approve. Original booking scope is immutable.
// Price difference is explicit — worker can never unilaterally raise the price.

export const scopeChangeController = {
  // GET /scope-changes/:bookingId — list all change requests for a booking
  listForBooking: async (req: AuthRequest, res: Response) => {
    try {
      const booking = await prisma.booking.findUnique({ where: { id: req.params.bookingId } });
      if (!booking) return sendError(res, 404, 'Booking not found');
      if (booking.customerId !== req.user!.userId && booking.workerId !== req.user!.userId) {
        return sendError(res, 403, 'Not your booking');
      }
      const changes = await prisma.scopeChangeRequest.findMany({
        where: { bookingId: req.params.bookingId },
        orderBy: { createdAt: 'desc' },
      });
      sendResponse(res, 200, changes);
    } catch (e: any) { sendError(res, 500, e.message); }
  },

  // POST /scope-changes/:bookingId/propose — worker proposes a scope change
  propose: async (req: AuthRequest, res: Response) => {
    try {
      const { bookingId } = req.params;
      const { reason, newScope, newPrice } = req.body;
      const workerId = req.user!.userId;

      if (!reason || !newScope) return sendError(res, 400, 'Reason and new scope required');
      if (!newPrice || newPrice <= 0) return sendError(res, 400, 'Valid new price required');

      const booking = await prisma.booking.findUnique({ where: { id: bookingId } });
      if (!booking) return sendError(res, 404, 'Booking not found');
      if (booking.workerId !== workerId) return sendError(res, 403, 'Only the assigned worker can propose changes');

      // Only during active states (not completed/cancelled)
      if (['COMPLETED', 'CANCELLED', 'DISPUTED'].includes(booking.status)) {
        return sendError(res, 400, 'Cannot change scope at this stage');
      }

      // No pending unresolved change allowed
      const pending = await prisma.scopeChangeRequest.findFirst({
        where: { bookingId, status: 'PENDING' },
      });
      if (pending) return sendError(res, 400, 'A pending change request already exists');

      const change = await prisma.scopeChangeRequest.create({
        data: {
          bookingId,
          proposedById: workerId,
          reason,
          oldScope: booking.scope as any,
          oldPrice: booking.negotiatedAmount || booking.baseAmount,
          newScope,
          newPrice,
          priceDifference: (booking.negotiatedAmount || booking.baseAmount || 0) - newPrice,
          status: 'PENDING',
        },
      });

      // Notify customer
      await notificationService.sendPushNotification(
        booking.customerId,
        'Scope Change Proposed',
        `The worker proposed a change to your booking scope.`,
        'scope_change',
        { bookingId, changeId: change.id },
      );
      emitToUser(booking.customerId, 'scope_change_proposed', { bookingId, changeId: change.id });
      emitToBooking(bookingId, 'scope_change_proposed', { changeId: change.id });

      sendResponse(res, 201, change, 'Scope change proposed to customer');
    } catch (e: any) { sendError(res, 500, e.message); }
  },

  // POST /scope-changes/:id/respond — customer approves or rejects
  respond: async (req: AuthRequest, res: Response) => {
    try {
      const { id } = req.params;
      const { decision } = req.body; // 'APPROVED' | 'REJECTED'
      const customerId = req.user!.userId;

      if (!['APPROVED', 'REJECTED'].includes(decision)) return sendError(res, 400, 'Decision must be APPROVED or REJECTED');

      const change = await prisma.scopeChangeRequest.findUnique({
        where: { id },
        include: { booking: { select: { customerId: true, workerId: true } } },
      });
      if (!change) return sendError(res, 404, 'Change request not found');
      if (change.booking.customerId !== customerId) return sendError(res, 403, 'Only the customer can respond');
      if (change.status !== 'PENDING') return sendError(res, 400, 'Change request already resolved');

      const result = await prisma.$transaction(async (tx) => {
        await tx.scopeChangeRequest.update({
          where: { id },
          data: { status: decision, respondedAt: new Date(), respondedById: customerId },
        });

        // On approval: update booking scope + negotiated amount (history preserved in the change record)
        if (decision === 'APPROVED') {
          const newPrice = change.newPrice || 0;
          const booking = await tx.booking.findUnique({ where: { id: change.bookingId } });
          const platformFee = booking ? Math.round((newPrice * (booking.platformFeePercent || 15)) / 100) : 0;
          await tx.booking.update({
            where: { id: change.bookingId },
            data: {
              scope: change.newScope as any,
              negotiatedAmount: newPrice,
              totalAmount: newPrice,
              workerEarnings: newPrice - platformFee,
              platformFee,
            },
          });
        }
      });

      // Notify worker
      const workerId = change.booking.workerId;
      await notificationService.sendPushNotification(
        workerId,
        decision === 'APPROVED' ? 'Scope Change Approved' : 'Scope Change Rejected',
        decision === 'APPROVED' ? 'The customer approved your scope change.' : 'The customer rejected the scope change.',
        'scope_change',
        { bookingId: change.bookingId },
      );
      emitToUser(workerId, 'scope_change_response', { changeId: id, decision });
      emitToBooking(change.bookingId, 'scope_change_response', { changeId: id, decision });

      sendResponse(res, 200, null, `Scope change ${decision.toLowerCase()}`);
    } catch (e: any) { sendError(res, 500, e.message); }
  },
};
