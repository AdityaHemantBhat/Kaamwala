import { Request } from 'express';
import { prisma } from '../config/prisma';
import { env } from '../config/env';
import { BookingStatus, CancellationFeeStatus, SubscriptionPlan } from '@prisma/client';
import { createAuditLog } from '../utils/audit';
import { emitToUser, emitToBooking, emitToAdmins } from './socket.service';
import { notificationService } from './notification.service';
import { chatService } from './chat.service';
import { leakageDetector } from './leakage.service';
import { logger } from '../utils/logger';

// ─── Helpers ──────────────────────────────────────────────────────────────────

async function getLateCancellationFeeDefault(): Promise<number> {
  // Single source: CANCELLATION_COMPENSATION in MarketConfig (admin-managed), env as fallback.
  const comp = await getConfig('CANCELLATION_COMPENSATION', '');
  if (comp) return parseFloat(comp) || 50;
  try {
    const cfg = await prisma.appConfig.findUnique({ where: { key: 'LATE_CANCELLATION_FEE' } });
    if (cfg) return parseFloat(cfg.value) || 50;
  } catch {}
  return parseFloat(env.LATE_CANCELLATION_FEE || '50');
}

async function getConfig(key: string, fallback: string): Promise<string> {
  try {
    const cfg = await prisma.marketConfig.findUnique({ where: { key } });
    return cfg?.value || fallback;
  } catch { return fallback; }
}

/**
 * Snapshot the customer's subscription at cancellation time.
 * Returns BASIC if no active plan found.
 */
async function getSubscriptionPlanAtTime(userId: string): Promise<SubscriptionPlan> {
  try {
    const sub = await prisma.userSubscription.findUnique({ where: { userId } });
    if (sub && sub.status === 'active' && sub.plan !== 'BASIC') {
      return sub.plan;
    }
  } catch {}
  return SubscriptionPlan.BASIC;
}

/**
 * Calculate cancellation fee based on booking status and customer plan.
 * Returns { feeAmount, reason } where reason is a display message.
 */
async function calculateCancellationFee(
  status: BookingStatus,
  customerPlan: SubscriptionPlan,
): Promise<{ feeAmount: number; reason: string }> {
  // Completed / already cancelled — can't cancel
  if (status === BookingStatus.COMPLETED || status === BookingStatus.CANCELLED || status === BookingStatus.DISPUTED) {
    throw new Error('Booking cannot be cancelled at this stage');
  }

  // Free if before ON_THE_WAY (PENDING, NEGOTIATING, ACCEPTED)
  if (status === BookingStatus.PENDING || status === BookingStatus.NEGOTIATING || status === BookingStatus.ACCEPTED) {
    return { feeAmount: 0, reason: '' };
  }

  // ON_THE_WAY or IN_PROGRESS — check plan
  if (customerPlan === SubscriptionPlan.PLUS || customerPlan === SubscriptionPlan.PRO) {
    return { feeAmount: 0, reason: 'Free cancellation with your plan' };
  }

  // BASIC / Normal — late fee applies
  const fee = await getLateCancellationFeeDefault();
  return { feeAmount: fee, reason: `Late cancellation fee of ₹${fee}` };
}

// ─── Core Service ─────────────────────────────────────────────────────────────

export const cancellationService = {
  /**
   * Process a customer-initiated cancellation with full business logic.
   */
  async processCustomerCancellation(
    bookingId: string,
    customerId: string,
    reasonCategory: string = 'OTHER',
    cancelReason?: string,
  ) {
    // Fetch booking with customer info
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId },
      include: {
        customer: { select: { name: true } },
        worker: { select: { id: true, name: true, fcmToken: true } },
      },
    });

    if (!booking) throw new Error('Booking not found');
    if (booking.customerId !== customerId) throw new Error('Access denied');

    // State validation
    if (booking.status === BookingStatus.COMPLETED || booking.status === BookingStatus.CANCELLED || booking.status === BookingStatus.DISPUTED) {
      throw new Error('Booking cannot be cancelled at this stage');
    }

    // Idempotency check — already cancelled?
    const existing = await prisma.cancellationRecord.findUnique({ where: { bookingId } });
    if (existing) throw new Error('Booking already cancelled');

    // Snapshot subscription at cancellation time
    const customerPlan = await getSubscriptionPlanAtTime(customerId);

    // Calculate normal fee
    let { feeAmount, reason } = await calculateCancellationFee(booking.status, customerPlan);
    
    // Worker asked customer to cancel → never auto-charge the customer (PART 100)
    const WORKER_REQUESTED_REASONS = ['WORKER_REQUESTED_CANCEL', 'WORKER_ASKED_TO_CANCEL', 'WORKER_SUGGESTED_CANCEL'];
    if (WORKER_REQUESTED_REASONS.includes(reasonCategory)) {
      feeAmount = 0;
      reason = 'Worker requested cancellation — no charge to customer';
    }

    // Travel protection — applies when worker has genuinely begun protected travel
    // (travelProtectionEligibleAt set on On My Way). Applies to ALL booking types.
    let workerCompensationAmount = 0;
    if (booking.travelProtectionEligibleAt && !WORKER_REQUESTED_REASONS.includes(reasonCategory)) {
      const compensation = await getConfig('CANCELLATION_COMPENSATION', '50');
      workerCompensationAmount = parseFloat(compensation);
      if (customerPlan === SubscriptionPlan.PLUS || customerPlan === SubscriptionPlan.PRO) {
          feeAmount = 0;
          reason = 'Free late cancellation with your plan';
      } else {
          feeAmount = workerCompensationAmount;
          reason = `Late cancellation charge of ₹${workerCompensationAmount}`;
      }
    }

    // Compensation-farming detection — repeated pair pattern: request→accept→travel→cancel
    let reviewFlag: string | null = null;
    if (workerCompensationAmount > 0) {
      const recentCompensations = await prisma.cancellationRecord.count({
        where: {
          booking: { customerId, workerId: booking.workerId },
          workerCompensation: { gt: 0 },
          createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
        },
      });
      if (recentCompensations >= 3) reviewFlag = 'COMPENSATION_FARMING';
    }

    // Exec transactional update
    const result = await prisma.$transaction(async (tx) => {
      // Create cancellation record
      const record = await tx.cancellationRecord.create({
        data: {
          bookingId,
          cancelledBy: 'CUSTOMER',
          cancelReason: cancelReason || null,
          reasonCategory,
          customerPlan,
          feeAmount,
          feeStatus: feeAmount > 0 ? CancellationFeeStatus.PENDING : CancellationFeeStatus.PAID,
          workerCompensation: workerCompensationAmount,
          reviewFlag,
        },
      });

      // Update booking
      const updatedBooking = await tx.booking.update({
        where: { id: bookingId },
        data: {
          status: BookingStatus.CANCELLED,
          cancelledAt: new Date(),
          cancelledBy: 'CUSTOMER',
          cancelReason: cancelReason || null,
          cancellationCharge: feeAmount,
          workerCompensation: workerCompensationAmount,
          updatedAt: new Date(),
        },
      });

      // If fee applies, add to customer's pending balance + independent ledger row (Part 127)
      if (feeAmount > 0) {
        const custProfile = await tx.customerProfile.findUnique({ where: { userId: customerId }, select: { walletBalance: true } });
        await tx.customerProfile.update({
          where: { userId: customerId },
          data: { pendingCancellationFee: { increment: feeAmount } },
        });
        await tx.transaction.create({
          data: {
            userId: customerId,
            bookingId: booking.id,
            type: 'CANCELLATION_FEE',
            amount: feeAmount,
            description: `Late cancellation fee for booking #${booking.bookingNumber}`,
            status: 'completed',
            idempotencyKey: `cancel:fee:${bookingId}`, // Part 128 — no double charge on retry
          },
        }).catch(() => {});
      }

      // If worker compensation applies, pay worker immediately
      // (unless flagged as possible compensation farming → pending review, Part 99)
      if (workerCompensationAmount > 0 && !reviewFlag) {
        const workerWallet = await tx.workerProfile.findUnique({ where: { userId: booking.workerId }, select: { walletBalance: true } });
        await tx.workerProfile.update({
          where: { userId: booking.workerId },
          data: {
            walletBalance: { increment: workerCompensationAmount },
            totalEarned: { increment: workerCompensationAmount }
          }
        });

        await tx.transaction.create({
          data: {
            userId: booking.workerId,
            bookingId: booking.id,
            type: 'URGENT_CANCELLATION_COMPENSATION',
            amount: workerCompensationAmount,
            description: `Cancellation compensation for booking #${booking.bookingNumber}`,
            status: 'completed',
            idempotencyKey: `cancel:comp:${bookingId}`, // Part 128
            balanceBefore: workerWallet?.walletBalance ?? null,
            balanceAfter: workerWallet ? (workerWallet.walletBalance + workerCompensationAmount) : null,
          }
        });
      }

      return { record, updatedBooking };
    });

    // Chat system message
    const msgContent = cancelReason
      ? `Booking cancelled by you. Reason: ${reasonCategory} — ${cancelReason}`
      : `Booking cancelled by you. Reason: ${reasonCategory}`;
    try {
      await chatService.createSystemMessage(bookingId, customerId, msgContent);
    } catch (e) {
      logger.error('Failed to create system message for cancellation:', e);
    }

    // Notifications
    const friendlyReasonCategory = reasonCategory
      .replace(/_/g, ' ')
      .toLowerCase()
      .replace(/\b\w/g, (l) => l.toUpperCase());

    const notificationTitle = 'Booking Cancelled';
    const notificationBody = `Booking #${booking.bookingNumber} was cancelled. Reason: ${friendlyReasonCategory}`;
    await notificationService.sendPushNotification(
      booking.workerId,
      notificationTitle,
      notificationBody,
      'booking_update',
      { bookingId },
    );

    if (feeAmount > 0) {
      await notificationService.sendPushNotification(
        customerId,
        'Cancellation Fee Added',
        `A late cancellation fee of ₹${feeAmount} has been added to your account.`,
        'cancellation_fee',
        { bookingId, feeAmount },
      );
    }

    // Socket events
    emitToUser(booking.workerId, 'booking_status_update', result.updatedBooking);
    emitToBooking(bookingId, 'booking_status_update', result.updatedBooking);
    emitToAdmins('admin_refresh', { type: 'cancellation' });

    return { booking: result.updatedBooking, cancellationRecord: result.record };
  },

  /**
   * Process a worker-initiated cancellation.
   */
  async processWorkerCancellation(
    bookingId: string,
    workerId: string,
    cancelReason?: string,
    reasonCategory: string = 'WORKER_CANCELLED'
  ) {
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId },
      include: {
        customer: { select: { id: true, name: true, fcmToken: true } },
        worker: { select: { id: true, name: true } },
      },
    });

    if (!booking) throw new Error('Booking not found');
    if (booking.workerId !== workerId) throw new Error('Access denied');

    if (booking.status === BookingStatus.COMPLETED || booking.status === BookingStatus.CANCELLED || booking.status === BookingStatus.DISPUTED) {
      throw new Error('Booking cannot be cancelled at this stage');
    }

    const existing = await prisma.cancellationRecord.findUnique({ where: { bookingId } });
    if (existing) throw new Error('Booking already cancelled');

    // Snapshot subscription at cancellation time
    const customerPlan = await getSubscriptionPlanAtTime(booking.customerId);

    // Execute transactional update
    const result = await prisma.$transaction(async (tx) => {
      const record = await tx.cancellationRecord.create({
        data: {
          bookingId,
          cancelledBy: 'WORKER',
          cancelReason: cancelReason || null,
          reasonCategory,
          customerPlan,
          feeAmount: 0,
          feeStatus: CancellationFeeStatus.PAID,
          workerPenaltyApplied: false,
        },
      });

      const updatedBooking = await tx.booking.update({
        where: { id: bookingId },
        data: {
          status: BookingStatus.CANCELLED,
          cancelledAt: new Date(),
          cancelledBy: 'WORKER',
          cancelReason: cancelReason || null,
          updatedAt: new Date(),
        },
      });

      // Increment worker cancelled jobs
      await tx.workerProfile.update({
        where: { userId: workerId },
        data: { cancelledJobs: { increment: 1 } },
      });

      return { record, updatedBooking };
    });

    // Existing leakage detection
    try {
      const score = await leakageDetector.calculateWorkerRiskScore(workerId);
      await leakageDetector.applyPenalty(workerId, score);
    } catch (e) {
      logger.error('Leakage detection failed during worker cancellation:', e);
    }

    // Chat system message
    const msgContent = cancelReason
      ? `Booking cancelled by the worker. Reason: ${cancelReason}`
      : 'Booking cancelled by the worker.';
    try {
      await chatService.createSystemMessage(bookingId, workerId, msgContent);
    } catch (e) {
      logger.error('Failed to create system message for worker cancellation:', e);
    }

    // Notifications
    await notificationService.sendPushNotification(
      booking.customerId,
      'Booking Cancelled',
      `The worker cancelled booking #${booking.bookingNumber}. Reason: ${cancelReason || 'N/A'}`,
      'booking_update',
      { bookingId },
    );

    // Socket events
    emitToUser(booking.customerId, 'booking_status_update', result.updatedBooking);
    emitToBooking(bookingId, 'booking_status_update', result.updatedBooking);
    emitToAdmins('admin_refresh', { type: 'cancellation' });

    return { booking: result.updatedBooking, cancellationRecord: result.record };
  },

  // ─── User Queries ─────────────────────────────────────────────────────────

  async getUserCancellationHistory(userId: string, role: string) {
    const where = role === 'CUSTOMER'
      ? { booking: { customerId: userId } }
      : { booking: { workerId: userId } };

    return prisma.cancellationRecord.findMany({
      where,
      include: {
        booking: {
          select: {
            id: true,
            bookingNumber: true,
            serviceName: true,
            serviceCategory: true,
            totalAmount: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
  },

  async getPendingCancellationFee(userId: string): Promise<number> {
    try {
      const profile = await prisma.customerProfile.findUnique({
        where: { userId },
        select: { pendingCancellationFee: true },
      });
      return profile?.pendingCancellationFee || 0;
    } catch {
      return 0;
    }
  },

  // ─── Admin Methods ────────────────────────────────────────────────────────

  async adminGetCancellationRecords(page = 1, limit = 20, filters: any = {}) {
    const skip = (page - 1) * limit;
    const where: any = {};
    if (filters.feeStatus) where.feeStatus = filters.feeStatus;
    if (filters.cancelledBy) where.cancelledBy = filters.cancelledBy;

    const [records, total] = await Promise.all([
      prisma.cancellationRecord.findMany({
        skip,
        take: limit,
        where,
        include: {
          booking: {
            select: {
              id: true,
              bookingNumber: true,
              serviceName: true,
              totalAmount: true,
              customer: { select: { id: true, name: true } },
              worker: { select: { id: true, name: true } },
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.cancellationRecord.count({ where }),
    ]);

    return { records, total, page, limit };
  },

  async adminWaiveFee(recordId: string, adminId: string, reason: string = 'Admin waived', req?: Request) {
    const record = await prisma.cancellationRecord.findUnique({
      where: { id: recordId },
      include: { booking: { select: { customerId: true } } },
    });
    if (!record) throw new Error('Cancellation record not found');
    if (record.feeStatus !== CancellationFeeStatus.PENDING) throw new Error('Fee is not in PENDING status');
    if (record.feeAmount <= 0) throw new Error('No fee to waive');

    await prisma.$transaction(async (tx) => {
      await tx.cancellationRecord.update({
        where: { id: recordId },
        data: {
          feeStatus: CancellationFeeStatus.WAIVED,
          feeWaivedBy: adminId,
          feeWaivedReason: reason,
        },
      });

      // Decrement the pending fee on customer profile
      await tx.customerProfile.update({
        where: { userId: record.booking.customerId },
        data: { pendingCancellationFee: { decrement: record.feeAmount } },
      });

      await createAuditLog(tx, req, {
        userId: adminId,
        action: 'CANCELLATION_FEE_WAIVED',
        resource: 'CancellationRecord',
        resourceId: recordId,
        newValue: { feeAmount: record.feeAmount, reason },
      });
    });

    return prisma.cancellationRecord.findUnique({ where: { id: recordId } });
  },

  async adminRefundFee(recordId: string, adminId: string, req?: Request) {
    const record = await prisma.cancellationRecord.findUnique({
      where: { id: recordId },
      include: { booking: { select: { customerId: true } } },
    });
    if (!record) throw new Error('Cancellation record not found');
    if (record.feeStatus !== CancellationFeeStatus.PAID && record.feeStatus !== CancellationFeeStatus.PENDING) {
      throw new Error('Fee cannot be refunded');
    }
    if (record.feeAmount <= 0) throw new Error('No fee to refund');

    await prisma.$transaction(async (tx) => {
      await tx.cancellationRecord.update({
        where: { id: recordId },
        data: {
          feeStatus: CancellationFeeStatus.REFUNDED,
          feeRefundedBy: adminId,
          feeRefundedAt: new Date(),
        },
      });

      // If still pending, decrement the pending fee
      if (record.feeStatus === CancellationFeeStatus.PENDING) {
        await tx.customerProfile.update({
          where: { userId: record.booking.customerId },
          data: { pendingCancellationFee: { decrement: record.feeAmount } },
        });
      }

      // Create refund transaction
      await tx.transaction.create({
        data: {
          userId: record.booking.customerId,
          bookingId: record.bookingId,
          type: 'CANCELLATION_REFUND',
          amount: -record.feeAmount,
          description: `Refund of cancellation fee (₹${record.feeAmount})`,
          status: 'completed',
          reference: recordId,
          idempotencyKey: `cancel:refund:${recordId}`, // Part 128
        },
      });

      await createAuditLog(tx, req, {
        userId: adminId,
        action: 'CANCELLATION_FEE_REFUNDED',
        resource: 'CancellationRecord',
        resourceId: recordId,
        newValue: { feeAmount: record.feeAmount },
      });
    });

    return prisma.cancellationRecord.findUnique({ where: { id: recordId } });
  },

  async getCancellationStats() {
    const [
      totalCancellations,
      byReason,
      byFeeStatus,
      byPlan,
      totalFeeRevenue,
      topCancellers,
    ] = await Promise.all([
      prisma.cancellationRecord.count(),
      prisma.cancellationRecord.groupBy({
        by: ['reasonCategory'],
        _count: true,
        orderBy: { _count: { reasonCategory: 'desc' } },
      }),
      prisma.cancellationRecord.groupBy({
        by: ['feeStatus'],
        _count: true,
      }),
      prisma.cancellationRecord.groupBy({
        by: ['customerPlan'],
        _count: true,
      }),
      prisma.cancellationRecord.aggregate({
        where: { feeStatus: { in: [CancellationFeeStatus.PAID, CancellationFeeStatus.PENDING] } },
        _sum: { feeAmount: true },
      }),
      prisma.cancellationRecord.groupBy({
        by: ['cancelledBy'],
        _count: true,
        orderBy: { _count: { cancelledBy: 'desc' } },
      }),
    ]);

    return {
      totalCancellations,
      byReason,
      byFeeStatus,
      byPlan,
      totalFeeRevenue: totalFeeRevenue._sum.feeAmount || 0,
      topCancellers,
    };
  },

  /**
   * Collect pending cancellation fee after a successful payment.
   * Called from payment verification flow.
   */
  async collectPendingFee(userId: string, bookingId: string, paymentAmount: number): Promise<number> {
    const pendingFee = await this.getPendingCancellationFee(userId);
    if (pendingFee <= 0) return 0;

    const collectAmount = Math.min(pendingFee, paymentAmount);
    if (collectAmount <= 0) return 0;

    await prisma.$transaction(async (tx) => {
      // Decrement pending fee
      const custProfile = await tx.customerProfile.findUnique({ where: { userId }, select: { walletBalance: true, pendingCancellationFee: true } });
      await tx.customerProfile.update({
        where: { userId },
        data: { pendingCancellationFee: { decrement: collectAmount } },
      });

      // Find the oldest PENDING cancellation record; mark PAID only when fully collected
      const oldestPending = await tx.cancellationRecord.findFirst({
        where: {
          booking: { customerId: userId },
          feeStatus: CancellationFeeStatus.PENDING,
          feeAmount: { gt: 0 },
        },
        orderBy: { createdAt: 'asc' },
      });

      if (oldestPending && collectAmount >= oldestPending.feeAmount) {
        await tx.cancellationRecord.update({
          where: { id: oldestPending.id },
          data: {
            feeStatus: CancellationFeeStatus.PAID,
            feeCollectedAt: new Date(),
          },
        });
      }

      // Create collection transaction (idempotent — Part 128)
      await tx.transaction.create({
        data: {
          userId,
          bookingId,
          type: 'CANCELLATION_RECOVERY',
          amount: collectAmount,
          description: `Previous cancellation fee collection (₹${collectAmount})`,
          status: 'completed',
          idempotencyKey: `cancel:recover:${bookingId}`,
          balanceBefore: custProfile?.pendingCancellationFee ?? null,
          balanceAfter: custProfile ? (custProfile.pendingCancellationFee - collectAmount) : null,
        },
      }).catch(() => {});
    });

    return collectAmount;
  },

  async initiateCancellation(bookingId: string, userId: string, role: string, reasonCategory: string, cancelReason?: string) {
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId }
    });
    if (!booking) throw new Error('Booking not found');
    
    if (role === 'WORKER' && booking.workerId !== userId) throw new Error('Access denied');
    if (role === 'CUSTOMER' && booking.customerId !== userId) throw new Error('Access denied');

    if (booking.status === BookingStatus.COMPLETED || booking.status === BookingStatus.CANCELLED || booking.status === BookingStatus.DISPUTED) {
      throw new Error('Booking cannot be cancelled at this stage');
    }

    if (role === 'CUSTOMER') {
      return this.processCustomerCancellation(bookingId, userId, reasonCategory, cancelReason);
    }

    // Role is WORKER
    const isBeforeOnTheWay = ['PENDING', 'NEGOTIATING', 'ACCEPTED'].includes(booking.status);
    
    if (isBeforeOnTheWay) {
      return this.processWorkerCancellation(bookingId, userId, cancelReason, reasonCategory);
    }

    // After ON_THE_WAY
    if (reasonCategory === 'EMERGENCY' || reasonCategory === 'SAFETY' || reasonCategory === 'WRONG_LOCATION' || reasonCategory === 'UNABLE_TO_PERFORM') {
      return this.processWorkerCancellation(bookingId, userId, cancelReason, reasonCategory);
    }

    if (reasonCategory === 'CUSTOMER_REQUESTED') {
      const updated = await prisma.booking.update({
        where: { id: bookingId },
        data: {
          cancelRequestBy: 'WORKER',
          cancelRequestReason: reasonCategory,
          cancelRequestStatus: 'PENDING_CUSTOMER',
          cancelRequestAt: new Date()
        }
      });
      emitToUser(booking.customerId, 'booking_status_update', updated);
      emitToUser(booking.workerId, 'booking_status_update', updated);
      await notificationService.sendPushNotification(booking.customerId, 'Cancellation Request', 'Your worker says you requested to cancel.', 'cancel_request', { bookingId });
      return { booking: updated, requires_confirmation: true };
    }

    if (reasonCategory === 'CUSTOMER_UNREACHABLE') {
      if (booking.cancelRequestStatus === 'PENDING_CUSTOMER') {
        const diff = Date.now() - new Date(booking.cancelRequestAt!).getTime();
        if (diff < 5 * 60 * 1000) {
          throw new Error('You must wait 5 minutes before marking customer as unreachable.');
        }
        return this.processWorkerCancellation(bookingId, userId, cancelReason, reasonCategory);
      } else {
        const updated = await prisma.booking.update({
          where: { id: bookingId },
          data: {
            cancelRequestBy: 'WORKER',
            cancelRequestReason: 'CUSTOMER_UNREACHABLE',
            cancelRequestStatus: 'PENDING_CUSTOMER',
            cancelRequestAt: new Date()
          }
        });
        emitToUser(booking.customerId, 'booking_status_update', updated);
        emitToUser(booking.workerId, 'booking_status_update', updated);
        return { booking: updated, requires_confirmation: true, waiting: true };
      }
    }
    
    return this.processWorkerCancellation(bookingId, userId, cancelReason, reasonCategory);
  },

  async confirmCancellationRequest(bookingId: string, customerId: string) {
    const booking = await prisma.booking.findUnique({ where: { id: bookingId } });
    if (!booking || booking.customerId !== customerId) throw new Error('Not found');
    if (booking.cancelRequestStatus !== 'PENDING_CUSTOMER') throw new Error('No pending request');

    return this.processCustomerCancellation(bookingId, customerId, 'CUSTOMER_REQUESTED', 'Confirmed worker request');
  },

  async denyCancellationRequest(bookingId: string, customerId: string) {
    const booking = await prisma.booking.findUnique({ where: { id: bookingId } });
    if (!booking || booking.customerId !== customerId) throw new Error('Not found');
    if (booking.cancelRequestStatus !== 'PENDING_CUSTOMER') throw new Error('No pending request');

    const updated = await prisma.booking.update({
      where: { id: bookingId },
      data: {
        cancelRequestStatus: 'CUSTOMER_DENIED',
        updatedAt: new Date()
      }
    });
    emitToUser(booking.workerId, 'booking_status_update', updated);
    emitToUser(booking.customerId, 'booking_status_update', updated);
    return { booking: updated };
  }
};
