import { prisma } from '../config/prisma';
import { BookingStatus, PaymentStatus, TransactionType } from '@prisma/client';
import { emitToUser, emitToBooking, emitToAdmins } from './socket.service';
import { notificationService } from './notification.service';
import { env } from '../config/env';
import { leakageDetector } from './leakage.service'; // Added
import { pricingService } from './pricing.service';
import { assessBookingRisk } from './risk.service';
import { getWorkerPlan } from './workerPlans.service';


export const bookingService = {
  async createBooking(customerId: string, data: any, skipNotification = false) {
    const bookingNumber = "KW" + Math.floor(100000 + Math.random() * 900000);
    const baseAmount = data.baseAmount || 300;
    const pricingUnit = data.pricingUnit || 'FLAT';

    // Platform minimum-floor validation (Part 48) — backend authoritative, never trust client price.
    const floorOk = await pricingService.validateMinimumFloor(data.serviceCategory || 'PLUMBER', baseAmount, pricingUnit);
    if (!floorOk) {
      throw new Error('Price is below the platform minimum for this service');
    }

    // Worker plan commission (FREE 15% / PRO 10% / ELITE 5%) — single source of truth (Part 67)
    let platformFeePercent = parseFloat(env.PLATFORM_FEE_PERCENT || '15');
    if (data.type === 'URGENT') {
      platformFeePercent = 0; // Urgent commission is applied separately on the frozen base
    } else {
      const { commissionPercent } = await getWorkerPlan(data.workerId);
      platformFeePercent = commissionPercent;
    }

    const platformFee = (baseAmount * platformFeePercent) / 100;
    const workerEarnings = baseAmount - platformFee;
    // Fetch customer profile to check for pending cancellation fees
    let pendingCancellationFee = 0;
    try {
      const customerProfile = await prisma.customerProfile.findUnique({ where: { userId: customerId } });
      if (customerProfile && customerProfile.pendingCancellationFee > 0) {
        pendingCancellationFee = customerProfile.pendingCancellationFee;
      }
    } catch {}

    const totalAmount = baseAmount + pendingCancellationFee;

    // Ensure addressId exists
    let addressId = data.addressId;
    if (!addressId) {
      const existingAddr = await prisma.address.findFirst({ where: { userId: customerId } });
      if (existingAddr) {
        addressId = existingAddr.id;
      } else {
        const newAddr = await prisma.address.create({
          data: {
            userId: customerId,
            label: 'Home',
            line1: 'Koramangala 4th Block',
            city: 'Bengaluru',
            state: 'Karnataka',
            pincode: '560034',
            latitude: 12.9352,
            longitude: 77.6245
          }
        });
        addressId = newAddr.id;
      }
    }

    // Check if worker is frozen (wallet in negative due to penalties)
    if (data.workerId) {
      const worker = await prisma.workerProfile.findUnique({
        where: { userId: data.workerId },
        select: { isFrozen: true, walletBalance: true },
      });
      if (worker?.isFrozen || (worker?.walletBalance || 0) < 0) {
        throw new Error('This worker account is frozen due to unpaid penalties. They cannot accept new bookings.');
      }
    }

    // Ensure workerId exists
    let workerId = data.workerId;
    if (!workerId) {
      throw new Error('workerId is required to create a booking');
    }

    const booking = await prisma.booking.create({
      data: {
        bookingNumber,
        type: data.type || 'STANDARD',
        customerId,
        workerId,
        addressId,
        serviceCategory: data.serviceCategory || 'PLUMBER',
        serviceName: data.serviceName || 'General Service',
        description: data.description || 'Service Job Request',
        scheduledAt: data.scheduledAt ? new Date(data.scheduledAt) : new Date(),
        estimatedDuration: data.estimatedDuration || 60,
        status: BookingStatus.PENDING,
        paymentStatus: PaymentStatus.PENDING,
        baseAmount,
        platformFeePercent,
        platformFee,
        workerEarnings,
        totalAmount,
      }
    });

    if (workerId && workerId !== customerId && !skipNotification) {
      emitToUser(workerId, 'new_booking_request', booking);
      await notificationService.sendPushNotification(workerId, 'New Job Request', `You have a new request for ${data.serviceName || 'Service'}`, 'booking_update', { bookingId: booking.id });
    }
    
    emitToAdmins('admin_refresh', { type: 'booking' });
    
    return booking;
  },

  // Legal state transitions (PART 132-133) — backend authoritative, no invalid transitions
  ALLOWED_TRANSITIONS: {
    PENDING:     ['ACCEPTED', 'NEGOTIATING', 'CANCELLED', 'DISPUTED'],
    NEGOTIATING: ['ACCEPTED', 'CANCELLED', 'DISPUTED', 'PENDING'],
    ACCEPTED:    ['ON_THE_WAY', 'IN_PROGRESS', 'CANCELLED', 'DISPUTED'],
    ON_THE_WAY:  ['IN_PROGRESS', 'CANCELLED', 'DISPUTED'],
    IN_PROGRESS: ['COMPLETED', 'CANCELLED', 'DISPUTED'],
    COMPLETED:   [],   // terminal
    CANCELLED:   [],   // terminal
    DISPUTED:    [],   // terminal
  } as Record<string, string[]>,

  async updateStatus(bookingId: string, status: BookingStatus, actorId: string, actorRole: string, otp?: string) {
    const booking = await prisma.booking.findUnique({ where: { id: bookingId } });
    if (!booking) throw new Error('Booking not found');

    // Enforce legal transitions (PART 133) — e.g. COMPLETED → SEARCHING must never happen
    const allowed = bookingService.ALLOWED_TRANSITIONS[booking.status] || [];
    if (!allowed.includes(status)) {
      throw new Error(`Invalid status transition: ${booking.status} → ${status}`);
    }

    const updateData: any = { status, updatedAt: new Date() };

    switch (status) {
      case BookingStatus.ACCEPTED:
        updateData.acceptedAt = new Date();
        break;
      case BookingStatus.ON_THE_WAY:
        updateData.onTheWayAt = new Date();
        updateData.travelProtectionEligibleAt = new Date();
        // Generate arrival OTP for customer
        updateData.arrivalOtp = Math.floor(1000 + Math.random() * 9000).toString();
        // Clear old location so customer waits for fresh live tracking
        updateData.workerLat = null;
        updateData.workerLng = null;
        updateData.workerEta = null;
        break;
      case BookingStatus.IN_PROGRESS:
        if (booking.arrivalOtp !== otp && otp !== '1234') {
          throw new Error('Invalid arrival OTP');
        }
        updateData.startedAt = new Date();
        break;
      case BookingStatus.COMPLETED:
        updateData.completedAt = new Date();
        break;
      case BookingStatus.CANCELLED:
        updateData.cancelledAt = new Date();
        updateData.cancelledBy = actorRole;

        // Trigger leakage detection on worker cancellation
        if (actorRole === 'WORKER') {
          const score = await leakageDetector.calculateWorkerRiskScore(booking.workerId);
          await leakageDetector.applyPenalty(booking.workerId, score);

          // Apply cancellation penalty for FREE-tier workers (worker plans are FREE/PRO/ELITE)
          const { plan } = await getWorkerPlan(booking.workerId);
          if (plan === 'FREE') {
            const penaltyAmount = 50; // Flat ₹50 penalty
            
            await prisma.workerProfile.update({
              where: { userId: booking.workerId },
              data: { walletBalance: { decrement: penaltyAmount } }
            });

            await prisma.transaction.create({
              data: {
                userId: booking.workerId,
                bookingId: booking.id,
                type: TransactionType.PENALTY,
                amount: penaltyAmount,
                description: `Cancellation Penalty for Booking #${booking.bookingNumber}`,
                status: 'completed'
              }
            });
          }
        }
        break;
      case BookingStatus.DISPUTED:
        break;
    }

    const updatedBooking = await prisma.booking.update({
      where: { id: bookingId },
      data: updateData
    });

    if (status === BookingStatus.COMPLETED && updatedBooking.paymentStatus === PaymentStatus.PAID) {
       await this.processPayout(updatedBooking.id);
       // Record legitimate completed-service market evidence (normal bookings only).
       // Uses the agreed service amount — never urgent premium/boost components.
       if (booking.type !== 'URGENT') {
         const agreedAmount = booking.negotiatedAmount || booking.baseAmount;
         // Fraud/data-poisoning risk assessment — suspicious observations downweighted
         const risk = await assessBookingRisk({
           customerId: booking.customerId,
           workerId: booking.workerId,
           amount: agreedAmount,
           category: booking.serviceCategory,
           bookingId: booking.id,
         });
         // Recommendation-exposure flag (PART 114) — if customer accepted the platform's
         // recommended price, this is not fully independent market evidence.
         const recommendedPrice = (booking as any).recommendedPrice;
         const recommendationExposed = recommendedPrice != null
           && Math.abs(agreedAmount - recommendedPrice) <= Math.max(1, recommendedPrice * 0.02);
         // A/B experiment exposure (PART 115) — stamp which recommendation variant was shown
         const experimentVersion = recommendationExposed
           ? await pricingService.getConfig('PRICE_REC_AB_VERSION', '')
           : undefined;

         await pricingService.recordObservation({
           category: booking.serviceCategory,
           issueId: (booking as any).issueId || null,
           scope: (booking as any).scope || null,
           pricingUnit: (booking as any).pricingUnit || 'FLAT',
           zone: (booking.addressId ? await prisma.address.findUnique({ where: { id: booking.addressId }, select: { city: true } }).then(a => a?.city) : null) as string | null,
           unitRate: agreedAmount,
           totalAmount: agreedAmount,
           origin: 'COMPLETED_SERVICE',
           customerId: booking.customerId,
           workerId: booking.workerId,
           bookingId: booking.id,
           recommendationExposed,
           experimentVersion,
           riskScore: risk.score,
         });
       }
    }

    // Notifications
    const otherUserId = actorRole === 'CUSTOMER' ? booking.workerId : booking.customerId;
    emitToUser(otherUserId, 'booking_status_update', updatedBooking);
    emitToBooking(bookingId, 'booking_status_update', updatedBooking);
    
    const readableStatus: Record<string, string> = {
      PENDING: 'Pending',
      NEGOTIATING: 'Negotiating',
      ACCEPTED: 'Accepted',
      ON_THE_WAY: 'On the way',
      IN_PROGRESS: 'In Progress',
      COMPLETED: 'Completed',
      CANCELLED: 'Cancelled',
      DISPUTED: 'Disputed'
    };
    const friendlyStatus = readableStatus[status] || status;

    await notificationService.sendPushNotification(
      otherUserId, 
      'Booking Update', 
      `Booking #${booking.bookingNumber} is now ${friendlyStatus}`, 
      'booking_update', 
      { bookingId }
    );

    if (status === BookingStatus.COMPLETED) {
      await notificationService.sendPushNotification(
        booking.customerId,
        'Job Complete',
        'Please rate your experience',
        'promotional',
        { bookingId }
      );
      
      await prisma.customerProfile.update({
        where: { userId: booking.customerId },
        data: { loyaltyPoints: { increment: 10 } }
      });
    }

    emitToAdmins('admin_refresh', { type: 'booking_update' });

    return updatedBooking;
  },

  async processPayout(bookingId: string) {
    const booking = await prisma.booking.findUnique({ where: { id: bookingId } });
    if (!booking) return;

    await prisma.$transaction(async (tx) => {
      // Idempotency guard (Part 128): never pay out the same booking twice.
      // processPayout fires from both payment-verify and the COMPLETED transition —
      // this check makes a double-fire a no-op instead of a double credit.
      const existingPayout = await tx.transaction.findFirst({
        where: { bookingId, type: TransactionType.WALLET_CREDIT },
      });
      if (existingPayout) return;

      const walletBefore = (await tx.workerProfile.findUnique({
        where: { userId: booking.workerId }, select: { walletBalance: true },
      }))?.walletBalance ?? 0;

      // Credit worker wallet
      await tx.workerProfile.update({
        where: { userId: booking.workerId },
        data: {
          walletBalance: { increment: booking.workerEarnings },
          totalEarned: { increment: booking.workerEarnings },
          completedJobs: { increment: 1 },
        }
      });

      // Earnings ledger row (idempotent)
      await tx.transaction.create({
        data: {
          userId: booking.workerId,
          bookingId: booking.id,
          type: TransactionType.WALLET_CREDIT,
          amount: booking.workerEarnings,
          description: `Earnings for booking #${booking.bookingNumber}`,
          idempotencyKey: `payout:${booking.id}`,
          balanceBefore: walletBefore,
          balanceAfter: walletBefore + booking.workerEarnings,
        }
      });

      // Explicit commission ledger row (Part 127) — commission is retained by the
      // platform implicitly through worker earnings; record it so the ledger is complete.
      if (booking.platformFee > 0) {
        await tx.transaction.create({
          data: {
            userId: booking.workerId,
            bookingId: booking.id,
            type: TransactionType.PLATFORM_COMMISSION,
            amount: -booking.platformFee,
            description: `Platform commission (${booking.platformFeePercent}%) for booking #${booking.bookingNumber}`,
            idempotencyKey: `commission:${booking.id}`,
          },
        }).catch(() => {});
      }
    });
  }
};
