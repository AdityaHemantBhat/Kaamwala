import axios from 'axios';
import { prisma } from '../config/prisma';
import { env } from '../config/env';

const GOOGLE_MAPS_BASE = 'https://maps.googleapis.com/maps/api';

function decodePolyline(encoded: string): { latitude: number; longitude: number }[] {
  const points: { latitude: number; longitude: number }[] = [];
  let index = 0, lat = 0, lng = 0;
  while (index < encoded.length) {
    let b, shift = 0, result = 0;
    do { b = encoded.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    const dlat = ((result & 1) ? ~(result >> 1) : (result >> 1));
    lat += dlat;
    shift = 0; result = 0;
    do { b = encoded.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    const dlng = ((result & 1) ? ~(result >> 1) : (result >> 1));
    lng += dlng;
    points.push({ latitude: lat / 1e5, longitude: lng / 1e5 });
  }
  return points;
}

export const mapsService = {
  async getETA(originLat: number, originLng: number, destLat: number, destLng: number): Promise<number | null> {
    try {
      if (!env.GOOGLE_MAPS_API_KEY) return null;

      const res = await axios.get(`${GOOGLE_MAPS_BASE}/distancematrix/json`, {
        params: {
          origins: `${originLat},${originLng}`,
          destinations: `${destLat},${destLng}`,
          key: env.GOOGLE_MAPS_API_KEY,
          mode: 'driving',
          units: 'metric',
        },
      });

      if (res.data?.rows?.[0]?.elements?.[0]?.status === 'OK') {
        return res.data.rows[0].elements[0].duration.value; // seconds
      }
      return null;
    } catch {
      return null;
    }
  },

  async updateWorkerLocation(workerProfileId: string, bookingId: string, lat: number, lng: number, accuracy?: number) {
    // Store location
    await prisma.workerLocation.create({
      data: { workerProfileId, bookingId, latitude: lat, longitude: lng, accuracy },
    });

    // Update worker's current position
    await prisma.workerProfile.update({
      where: { id: workerProfileId },
      data: { latitude: lat, longitude: lng, lastLocationAt: new Date() },
    });

    // Calculate ETA to customer's address
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId },
      include: { address: true },
    });

    if (!booking?.address) return { lat, lng, eta: null };

    const etaSeconds = await this.getETA(lat, lng, booking.address.latitude, booking.address.longitude);

    if (etaSeconds !== null) {
      const etaMinutes = Math.round(etaSeconds / 60);
      await prisma.booking.update({
        where: { id: bookingId },
        data: { workerLat: lat, workerLng: lng, workerEta: etaMinutes },
      });
      return { lat, lng, eta: etaMinutes, etaSeconds };
    }

    return { lat, lng, eta: null };
  },

  async getWorkerLocation(bookingId: string) {
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId },
      select: { workerLat: true, workerLng: true, workerEta: true },
    });
    return booking || { workerLat: null, workerLng: null, workerEta: null };
  },

  async getLocationHistory(workerProfileId: string, bookingId: string) {
    return prisma.workerLocation.findMany({
      where: { workerProfileId, bookingId },
      orderBy: { recordedAt: 'desc' },
      take: 10,
    });
  },

  // Alert when worker is 5 min away
  async checkEtaAlert(bookingId: string, etaMinutes: number): Promise<boolean> {
    if (etaMinutes <= 5 && etaMinutes > 0) {
      const booking = await prisma.booking.findUnique({ where: { id: bookingId } });
      if (booking && !booking.safetyAlertSentAt) {
        await prisma.booking.update({
          where: { id: bookingId },
          data: { safetyAlertSentAt: new Date() },
        });
        return true; // should trigger notification
      }
    }
    return false;
  },

  async getDirections(originLat: number, originLng: number, destLat: number, destLng: number) {
    try {
      if (!env.GOOGLE_MAPS_API_KEY) return null;

      const res = await axios.get(`${GOOGLE_MAPS_BASE}/directions/json`, {
        params: {
          origin: `${originLat},${originLng}`,
          destination: `${destLat},${destLng}`,
          key: env.GOOGLE_MAPS_API_KEY,
          mode: 'driving',
          units: 'metric',
          traffic_model: 'best_guess',
          departure_time: 'now',
        },
      });

      if (res.data?.status === 'OK' && res.data.routes?.[0]) {
        const route = res.data.routes[0];
        // Decode polyline
        const points = route.overview_polyline?.points || '';
        const decoded = decodePolyline(points);
        return {
          polyline: decoded,
          distance: route.legs?.[0]?.distance?.text || '',
          duration: route.legs?.[0]?.duration?.text || '',
          durationSeconds: route.legs?.[0]?.duration?.value || 0,
        };
      }
      return null;
    } catch { return null; }
  },
};
