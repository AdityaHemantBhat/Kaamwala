import { Server } from 'socket.io';
import { logger } from '../utils/logger';
import { verifyAccessToken } from '../utils/crypto';
import { haversineDistance } from '../utils/haversine';
import { prisma } from '../config/prisma';
import { createAuditLog, AuditContext } from '../utils/audit';
import { mapsService } from './maps.service';
import { notificationService } from './notification.service';

let io: Server;
let locationUpdateCounter = 0;

// Fallback in-memory violation tracker (used when Redis is unavailable)
const memoryViolations = new Map<string, { count: number }>();

// Financial penalties escalate with each violation
function getPenaltyAmount(count: number): number {
  if (count <= 1) return 0;     // 1st: warning only
  if (count === 2) return 30;   // 2nd: Rs.30
  if (count === 3) return 70;   // 3rd: Rs.70
  return 0;                     // 4th: ban (handled separately, no penalty)
}

async function applyFinancialPenalty(userId: string, amount: number): Promise<{ deducted: boolean; walletBalance: number }> {
  if (amount <= 0) return { deducted: false, walletBalance: 0 };

  try {
    // Check if user is a worker (has WorkerProfile with wallet)
    const workerProfile = await prisma.workerProfile.findUnique({ where: { userId } });
    if (workerProfile) {
      const currentBalance = workerProfile.walletBalance || 0;
      const newBalance = currentBalance - amount;

      const updated = await prisma.workerProfile.update({
        where: { userId },
        data: { walletBalance: newBalance, isFrozen: newBalance < 0 },
      });

      await prisma.transaction.create({
        data: { userId, bookingId: undefined, type: 'PENALTY', amount: -amount,
          description: newBalance < 0
            ? 'Penalty for sharing contact info. Wallet overdrawn to Rs.' + newBalance + '. Add funds to unfreeze.'
            : 'Penalty for sharing contact info (Rs.' + amount + ')',
          status: 'completed',
        },
      });

      return { deducted: true, walletBalance: updated.walletBalance };
    }

    // Check if user is a customer (has CustomerProfile with wallet)
    const customerProfile = await prisma.customerProfile.findUnique({ where: { userId } });
    if (customerProfile) {
      const currentBalance = customerProfile.walletBalance || 0;
      const newBalance = currentBalance - amount;

      await prisma.customerProfile.update({
        where: { userId },
        data: { walletBalance: newBalance },
      });

      await prisma.transaction.create({
        data: { userId, bookingId: undefined, type: 'PENALTY', amount: -amount,
          description: 'Penalty for sharing contact info (Rs.' + amount + ')',
          status: 'completed',
        },
      });

      return { deducted: true, walletBalance: newBalance };
    }

    // No wallet found — can't deduct
    return { deducted: false, walletBalance: 0 };
  } catch (e) {
    logger.error('Failed to apply financial penalty:', e);
    return { deducted: false, walletBalance: 0 };
  }
}

async function applyBan(userId: string, reason: string, permanent: boolean = false, ctx?: AuditContext): Promise<void> {
  try {
    const data: any = {
      banReason: reason,
      bannedAt: new Date(),
      isAvailable: false,
      isOnline: false,
    };
    if (permanent) {
      data.isPermanentlyBanned = true;
      data.isBanned = false;
    } else {
      data.isBanned = true;
    }
    const exists = await prisma.workerProfile.findUnique({ where: { userId }, select: { id: true } });
    if (exists) {
      await prisma.workerProfile.update({ where: { userId }, data });
    }
    await createAuditLog(prisma, ctx, {
      userId,
      action: permanent ? 'WORKER_PERMANENTLY_BANNED' : 'WORKER_BANNED',
      resource: 'worker',
      resourceId: userId,
      newValue: { reason, timestamp: new Date().toISOString() },
    });
  } catch (e) {
    logger.error('Failed to apply ban:', e);
  }
}

async function getViolationCount(userId: string): Promise<number> {
  try {
    const { redis } = await import('../config/redis');
    const val = await redis.get(`chat_violations:${userId}`);
    return val ? parseInt(val, 10) : 0;
  } catch {
    return memoryViolations.get(userId)?.count || 0;
  }
}

async function incrementViolation(userId: string, ctx?: AuditContext): Promise<{ count: number; penalty: number; deducted: boolean; walletBalance: number }> {
  let newCount = 0;
  try {
    const { redis } = await import('../config/redis');
    newCount = await redis.incr(`chat_violations:${userId}`);
  } catch {
    const record = memoryViolations.get(userId) || { count: 0 };
    record.count++;
    memoryViolations.set(userId, record);
    newCount = record.count;
  }

  const penaltyAmount = getPenaltyAmount(newCount);
  let walletBalance = 0;
  let deducted = false;

  // 4th violation = ban (check if already been unbanned before)
  if (newCount >= 4) {
    const profile = await prisma.workerProfile.findUnique({ where: { userId }, select: { isPermanentlyBanned: true, appealCount: true } });
    if (profile?.isPermanentlyBanned) {
      // Already had a chance — permanent ban, no appeal
      await applyBan(userId, 'Permanent ban: violated after previous appeal was granted.', true, ctx);
    } else if (profile && profile.appealCount > 0) {
      // This is a violation AFTER being unbanned via appeal — permanent ban
      await applyBan(userId, 'Permanent ban: violated after appeal.', true, ctx);
    } else {
      // First ban — can appeal
      await applyBan(userId, 'Banned: multiple chat violations (sharing contact info). You can appeal this ban.', false, ctx);
    }
  }

  if (penaltyAmount > 0) {
    const result = await applyFinancialPenalty(userId, penaltyAmount);
    deducted = result.deducted;
    walletBalance = result.walletBalance;
  }

  try {
    await createAuditLog(prisma, ctx, {
      userId,
      action: 'CHAT_PHONE_SHARE',
      resource: 'chat',
      resourceId: userId,
      newValue: { count: newCount, penalty: penaltyAmount, walletBalance, windowHours: 24, timestamp: new Date().toISOString() },
    });
  } catch (e) {
    logger.error('Failed to log chat violation:', e);
  }

  return { count: newCount, penalty: penaltyAmount, deducted, walletBalance };
}

async function checkChatMute(userId: string): Promise<{ allowed: boolean; reason?: string; mutedForSec?: number }> {
  try {
    const { redis } = await import('../config/redis');
    const ttl = await redis.ttl(`chat_muted:${userId}`);
    if (ttl > 0) {
      return { allowed: false, reason: `Muted for ${ttl}s`, mutedForSec: ttl };
    }
  } catch {
    const record = memoryViolations.get(userId);
    if (record) {
      return { allowed: false, reason: `Muted (violation #${record.count})`, mutedForSec: 60 };
    }
  }
  return { allowed: true };
}

async function applyMute(userId: string, muteMs: number) {
  try {
    const { redis } = await import('../config/redis');
    if (muteMs > 0) {
      await redis.set(`chat_muted:${userId}`, '1', { PX: muteMs });
    }
  } catch { /* in-memory fallback */ }
}

async function checkFrozen(userId: string): Promise<boolean> {
  try {
    // Check worker profile
    const workerProfile = await prisma.workerProfile.findUnique({
      where: { userId },
      select: { isFrozen: true, walletBalance: true },
    });
    if (workerProfile) {
      return workerProfile?.isFrozen === true || (workerProfile?.walletBalance || 0) < 0;
    }
    // Check customer profile
    const customerProfile = await prisma.customerProfile.findUnique({
      where: { userId },
      select: { walletBalance: true },
    });
    if (customerProfile) {
      return (customerProfile?.walletBalance || 0) < 0;
    }
    return false;
  } catch {
    return false;
  }
}

async function checkBanned(userId: string): Promise<{ banned: boolean; permanent: boolean; reason?: string; canAppeal: boolean }> {
  try {
    const profile = await prisma.workerProfile.findUnique({
      where: { userId },
      select: { isBanned: true, isPermanentlyBanned: true, banReason: true },
    });
    if (profile?.isPermanentlyBanned) {
      return { banned: true, permanent: true, reason: profile.banReason || 'Permanently banned', canAppeal: false };
    }
    if (profile?.isBanned) {
      return { banned: true, permanent: false, reason: profile.banReason || 'Banned', canAppeal: true };
    }
    return { banned: false, permanent: false, canAppeal: false };
  } catch {
    return { banned: false, permanent: false, canAppeal: false };
  }
}

export const initSocket = (serverIo: Server) => {
  io = serverIo;
  
  io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    if (!token) return next(new Error('Authentication required'));
    
    try {
      const decoded = verifyAccessToken(token);
      socket.data.user = decoded;
      next();
    } catch (e) {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', (socket) => {
    const { userId, role } = socket.data.user;
    logger.info(`Socket connected: ${socket.id} for user ${userId} (${role})`);
    
    // Join personal room for notifications
    socket.join(`user_${userId}`);
    
    socket.on('join_booking_chat', ({ bookingId }) => {
      socket.join(`booking_${bookingId}`);
      logger.info(`User ${userId} joined chat room booking_${bookingId}`);
    });

        socket.on('send_message', async ({ bookingId, content }) => {
      // Check if user is banned (permanent or temporary)
      const banCheck = await checkBanned(userId);
      if (banCheck.banned) {
        socket.emit('chat_warning', {
          message: banCheck.permanent
            ? 'Your account is permanently banned. This decision is final.'
            : 'Your account is banned. You can appeal by paying a Rs.100 fee. Reason: ' + (banCheck.reason || 'N/A'),
          banned: true,
          permanent: banCheck.permanent,
          canAppeal: banCheck.canAppeal,
        });
        return;
      }

      // Check if user is frozen (unpaid penalty debt / negative wallet)
      const frozen = await checkFrozen(userId);
      if (frozen) {
        socket.emit('chat_warning', {
          message: 'Your account is frozen due to unpaid penalties. Clear your penalty debt to continue using chat.',
          frozen: true,
        });
        return;
      }

      // Deterministic Chat Filter — block phone numbers
      const phoneRegex = /(\d\s*[-.]?\s*){10}/g;
      if (phoneRegex.test(content)) {
        // CUSTOMER: educational warning, no penalty
        if (role === 'CUSTOMER') {
          socket.emit('chat_warning', {
            message: 'Stay protected with KaamWalla. Sharing contact details and completing the job outside KaamWalla may mean the transaction is not covered by KaamWalla support, applicable warranty, or platform protections.',
            educational: true,
          });
          return; // Don't emit to room
        }

        // WORKER: existing penalty system (violations, wallet deduction, bans)
        const result = await incrementViolation(userId, { ip: socket.handshake.address });

        let msg = 'Sharing contact info is prohibited.';
        if (result.penalty > 0) {
          if (result.walletBalance < 0) {
            msg = 'VIOLATION #' + result.count + ' — Rs.' + result.penalty + ' penalty. Wallet overdrawn to Rs.' + result.walletBalance + '. Account FROZEN. Add funds to unfreeze.';
          } else if (result.deducted) {
            msg = 'VIOLATION #' + result.count + ' — Rs.' + result.penalty + ' penalty deducted. Wallet balance: Rs.' + result.walletBalance + '.';
          } else {
            msg = 'VIOLATION #' + result.count + ' — Warning: sharing contact info is prohibited.';
          }
        } else {
          msg = 'WARNING #' + result.count + ' — Sharing contact info is prohibited. Next violation will incur a Rs.30 penalty.';
        }

        socket.emit('chat_warning', {
          message: msg,
          penalty: result.penalty,
          deducted: result.deducted,
          walletBalance: result.walletBalance,
          violations: result.count,
          frozen: result.walletBalance < 0,
        });
        return; // Don't emit to room
      }

      try {
        const message = await prisma.$transaction(async (tx) => {
          let chat = await tx.chat.findUnique({ where: { bookingId } });
          if (!chat) {
            chat = await tx.chat.create({ data: { bookingId } });
          }
          return await tx.message.create({
            data: { chatId: chat.id, senderId: userId, content: content, type: 'text' },
            include: { sender: { select: { name: true, role: true } } }
          });
        });

        io.to('booking_' + bookingId).emit('new_message', {
          id: message.id, chatId: message.chatId, senderId: message.senderId,
          sender: message.sender, type: message.type, content: message.content,
          mediaUrl: message.mediaUrl, isRead: message.isRead, isDeleted: message.isDeleted,
          createdAt: message.createdAt
        });

        try {
          const booking = await prisma.booking.findUnique({ where: { id: bookingId }, select: { customerId: true, workerId: true } });
          if (booking) {
            const recipientId = booking.customerId === userId ? booking.workerId : booking.customerId;
            const preview = content.substring(0, 100);
            await notificationService.sendPushNotification(recipientId, 'New message', preview, 'chat_message', { bookingId });
          }
        } catch {}

      } catch (error: any) {
        logger.error('Failed to save message:', error);
        socket.emit('message_error', 'Failed to send message');
      }
    });socket.on('worker:location_update', async ({ bookingId, lat, lng }) => {
      if (role === 'WORKER') {
        let eta: number | null = null;
        locationUpdateCounter++;
        try {
          const booking = await prisma.booking.findUnique({
            where: { id: bookingId },
            include: { address: true },
          });

          // Save to DB on EVERY update so customer polling works immediately
          if (booking?.address?.latitude && booking?.address?.longitude) {
            // Try Google Maps ETA every ~15th call, fallback to haversine
            if (locationUpdateCounter % 15 === 0) {
              try {
                const etaSeconds = await mapsService.getETA(lat, lng, booking.address.latitude, booking.address.longitude);
                if (etaSeconds !== null) eta = Math.round(etaSeconds / 60);
              } catch {}
            }
            if (eta === null) {
              const distKm = haversineDistance(lat, lng, booking.address.latitude, booking.address.longitude);
              if (distKm > 10) eta = null;  // Too far - don't show unreliable ETA
              else eta = Math.round(distKm / 0.5);
              if (distKm < 0.2) eta = 0;
            }
            // Always save to DB
            await prisma.booking.update({
              where: { id: bookingId },
              data: { workerLat: lat, workerLng: lng, workerEta: eta },
            });
          } else if (booking?.address?.city) {
            eta = 15;
          }

          const workerProfile = await prisma.workerProfile.findUnique({ where: { userId } });
          if (workerProfile) {
            await prisma.workerLocation.create({
              data: { workerProfileId: workerProfile.id, bookingId, latitude: lat, longitude: lng },
            });
          }
        } catch (e) { /* silent */ }

        io.to(`booking_${bookingId}`).emit('worker_location_updated', { lat, lng, eta });
      }
    });

    socket.on('worker:stop_sharing', async ({ bookingId }) => {
      if (role === 'WORKER') {
        try {
          await prisma.booking.update({
            where: { id: bookingId },
            data: { workerLat: null, workerLng: null, workerEta: null }
          });
        } catch (e) {}
        io.to(`booking_${bookingId}`).emit('worker_stopped_sharing');
      }
    });

    socket.on('disconnect', () => {
      logger.info(`Socket disconnected: ${socket.id}`);
    });
  });
};

export const getIo = () => {
  if (!io) {
    throw new Error('Socket.io not initialized!');
  }
  return io;
};

export const emitToUser = (userId: string, event: string, data: any) => {
  if (io) {
    io.to(`user_${userId}`).emit(event, data);
  }
};

export const emitToBooking = (bookingId: string, event: string, data: any) => {
  if (io) {
    io.to(`booking_${bookingId}`).emit(event, data);
  }
};

export const emitToAdmins = async (event: string, data: any) => {
  if (io) {
    try {
      const admins = await prisma.user.findMany({ where: { role: 'ADMIN' }, select: { id: true } });
      admins.forEach(a => {
        io.to(`user_${a.id}`).emit(event, data);
      });
    } catch (e) {
      logger.error('Error emitting to admins', e);
    }
  }
};
