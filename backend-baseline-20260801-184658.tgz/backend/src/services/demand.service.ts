import { prisma } from '../config/prisma';

export const demandService = {
  async getDemandStatus(category: string, city: string) {
    const now = new Date();
    const hour = now.getHours();
    const dayOfWeek = now.getDay();

    const signal = await prisma.demandSignal.findUnique({
      where: {
        category_city_hour_dayOfWeek: {
          category: category as any,
          city,
          hour,
          dayOfWeek,
        },
      },
    });

    if (!signal) return { demandScore: 1.0, surgeActive: false, surgeMultiplier: 1.0 };

    return {
      demandScore: signal.demandScore,
      surgeActive: signal.surgeActive,
      surgeMultiplier: signal.surgeMultiplier,
    };
  },

  async getAllCityDemands(city: string) {
    const now = new Date();
    const hour = now.getHours();
    const dayOfWeek = now.getDay();

    const signals = await prisma.demandSignal.findMany({
      where: { city, hour, dayOfWeek },
    });

    return signals.map(s => ({
      category: s.category,
      demandScore: s.demandScore,
      surgeActive: s.surgeActive,
      surgeMultiplier: s.surgeMultiplier,
    }));
  },

  async recalculateDemand() {
    const now = new Date();
    const hour = now.getHours();
    const dayOfWeek = now.getDay();

    // Get all distinct city + category combinations from recent bookings
    const recentBookings = await prisma.booking.findMany({
      where: {
        createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
      },
      select: { serviceCategory: true, address: { select: { city: true } } },
    });

    // Group by city + category
    const groups = new Map<string, Map<string, number>>();
    for (const b of recentBookings) {
      const city = b.address?.city || 'Unknown';
      if (!groups.has(city)) groups.set(city, new Map());
      const catMap = groups.get(city)!;
      catMap.set(b.serviceCategory, (catMap.get(b.serviceCategory) || 0) + 1);
    }

    // Get total available workers per city+category for supply
    const supplyData = await prisma.workerProfile.groupBy({
      by: ['city', 'category'],
      where: { isAvailable: true,
        isFrozen: false, verificationStatus: 'VERIFIED' },
      _count: true,
    });

    const supplyMap = new Map<string, number>();
    for (const s of supplyData) {
      const key = `${s.city}:${s.category}`;
      supplyMap.set(key, s._count);
    }

    // Calculate demand score and upsert signals
    for (const [city, categories] of groups) {
      for (const [category, bookingCount] of categories) {
        const supplyKey = `${city}:${category}`;
        const supply = supplyMap.get(supplyKey) || 1;
        const demandScore = Math.min((bookingCount / supply) * 0.5, 2.0);
        const surgeActive = demandScore > 1.3;
        const surgeMultiplier = surgeActive ? Math.min(1.0 + (demandScore - 1.3) * 0.5, 1.5) : 1.0;

        await prisma.demandSignal.upsert({
          where: {
            category_city_hour_dayOfWeek: {
              category: category as any,
              city,
              hour,
              dayOfWeek,
            },
          },
          update: { demandScore, surgeActive, surgeMultiplier, calculatedAt: now },
          create: {
            category: category as any,
            city,
            hour,
            dayOfWeek,
            demandScore,
            surgeActive,
            surgeMultiplier,
            calculatedAt: now,
          },
        });
      }
    }
  },
};
