import { Cashfree, CFEnvironment } from 'cashfree-pg';
import { prisma } from '../config/prisma';
import { env } from '../config/env';
import { logger } from '../utils/logger';

const cfEnv = env.CF_ENV === 'PRODUCTION' ? CFEnvironment.PRODUCTION : CFEnvironment.SANDBOX;
logger.info(`Cashfree init: env=${cfEnv}, appId=${env.CF_APP_ID ? env.CF_APP_ID.substring(0, 8) + '...' : 'MISSING'}`);

const cashfree = new Cashfree(cfEnv, env.CF_APP_ID, env.CF_SECRET_KEY);

export const paymentService = {
  async createOrder(bookingId: string, amount: number, customerId: string) {
    const user = await prisma.user.findUnique({ where: { id: customerId } });

    const request: any = {
      order_amount: String(amount),
      order_currency: 'INR',
      customer_details: {
        customer_id: customerId,
        customer_name: user?.name || 'Customer',
        customer_email: user?.email || 'customer@kaamwala.app',
        customer_phone: user?.phone || '9999999999',
      },
      order_meta: {
        return_url: `${env.API_URL}/api/v1/payments/callback?order_id={order_id}`,
      },
    };

    let response;
    try {
      response = await cashfree.PGCreateOrder(request);
    } catch (cfErr: any) {
      logger.error('Cashfree create order failed:', cfErr?.response?.data || cfErr?.message || cfErr);
      throw new Error(cfErr?.response?.data?.message || 'Cashfree order creation failed');
    }
    const order = response.data;

    if (!bookingId.startsWith('wrk_sub_') && !bookingId.startsWith('sub_') && !bookingId.startsWith('wallet_topup_')) {
      try {
        await prisma.booking.update({
          where: { id: bookingId },
          data: { paymentOrderId: order.order_id },
        });
      } catch (e) {
        logger.warn(`Could not attach paymentOrderId to booking ${bookingId}`);
      }
    }

    return {
      orderId: order.order_id,
      paymentSessionId: order.payment_session_id,
      amount: order.order_amount,
      currency: order.order_currency,
    };
  },

  async verifyPayment(bookingId: string, orderId: string) {
    const response = await cashfree.PGFetchOrder(orderId);
    const order = response.data;

    if (order.order_status === 'PAID') {
      if (!bookingId.startsWith('wallet_topup_')) {
        await prisma.booking.update({
          where: { id: bookingId },
          data: { paymentStatus: 'PAID', paymentRefId: order.cf_order_id },
        });
      }
      return true;
    }
    throw new Error('Payment not completed');
  },

  async verifyWalletOrder(orderId: string) {
    const response = await cashfree.PGFetchOrder(orderId);
    const order = response.data;

    if (order.order_status === 'PAID') {
      return { amount: order.order_amount };
    }
    throw new Error('Payment not completed');
  },
};