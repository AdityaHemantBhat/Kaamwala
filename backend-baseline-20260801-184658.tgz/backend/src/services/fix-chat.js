const fs = require('fs');
const path = 'd:/Adi Works/Android/KaamWalla/backend/src/services/socket.service.ts';
let c = fs.readFileSync(path, 'utf8');

// Replace getPenaltyAmount
c = c.replace(
  /function getPenaltyAmount\(count: number\): number \{[^}]+\}/,
  `function getPenaltyAmount(count: number): number {
  if (count <= 1) return 0;     // 1st: warning only
  if (count === 2) return 30;   // 2nd: Rs.30
  if (count === 3) return 70;   // 3rd: Rs.70
  return 0;                     // 4th: ban (handled separately, no penalty)`
);

// Add applyBan function after applyFinancialPenalty
const applyBanFn = `
async function applyBan(userId: string, reason: string, permanent: boolean = false): Promise<void> {
  try {
    const data: any = {
      banReason: reason,
      bannedAt: new Date(),
      isAvailable: false,
      isOnline: false,
    };
    if (permanent) {
      data.isPermanentlyBanned = true;
      data.isBanned = false;
    } else {
      data.isBanned = true;
    }
    await prisma.workerProfile.update({ where: { userId }, data });
    await prisma.auditLog.create({
      data: {
        userId,
        action: permanent ? 'WORKER_PERMANENTLY_BANNED' : 'WORKER_BANNED',
        resource: 'worker',
        resourceId: userId,
        newValue: { reason, timestamp: new Date().toISOString() },
      },
    });
  } catch (e) {
    logger.error('Failed to apply ban:', e);
  }
}
`;

// Insert after the closing brace of applyFinancialPenalty
const fnEnd = '  return { deducted: false, walletBalance: 0 };\n  }\n}';
c = c.replace(fnEnd + '\n\nasync function getViolationCount', fnEnd + '\n' + applyBanFn + '\nasync function getViolationCount');

// Update incrementViolation to handle bans on 4th violation
c = c.replace(
  /const penaltyAmount = getPenaltyAmount\(newCount\);\n  let walletBalance = 0;\n  let deducted = false;\n\n  if \(penaltyAmount > 0\)/,
  `const penaltyAmount = getPenaltyAmount(newCount);
  let walletBalance = 0;
  let deducted = false;

  // 4th violation = ban (check if already been unbanned before)
  if (newCount >= 4) {
    const profile = await prisma.workerProfile.findUnique({ where: { userId }, select: { isPermanentlyBanned: true, appealCount: true } });
    if (profile?.isPermanentlyBanned) {
      // Already had a chance — permanent ban, no appeal
      await applyBan(userId, 'Permanent ban: violated after previous appeal was granted.', true);
    } else if (profile && profile.appealCount > 0) {
      // This is a violation AFTER being unbanned via appeal — permanent ban
      await applyBan(userId, 'Permanent ban: violated after appeal.', true);
    } else {
      // First ban — can appeal
      await applyBan(userId, 'Banned: multiple chat violations (sharing contact info). You can appeal this ban.');
    }
  }

  if (penaltyAmount > 0)`
);

fs.writeFileSync(path, c);
console.log('Done');
