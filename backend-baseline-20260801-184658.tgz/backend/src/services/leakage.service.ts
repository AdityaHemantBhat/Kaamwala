import { prisma } from '../config/prisma';

export const leakageDetector = {
  async calculateWorkerRiskScore(workerId: string) {
    const worker = await prisma.workerProfile.findUnique({
      where: { userId: workerId },
      include: {
        user: {
          include: {
            bookingsAsWorker: {
              where: {
                OR: [
                  { status: 'CANCELLED' },
                  { status: 'PENDING' }
                ],
                createdAt: {
                  gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) // Last 30 days
                }
              }
            }
          }
        }
      }
    });

    if (!worker) return 0;

    let score = 0;

    // Metric 1: Cancellation Rate
    const totalJobs = worker.completedJobs + worker.cancelledJobs;
    if (totalJobs > 5) {
      const cancellationRate = worker.cancelledJobs / totalJobs;
      if (cancellationRate > 0.2) score += 40;
      if (cancellationRate > 0.4) score += 30; // Total 70
    }

    // Metric 2: Rapid Cancellations (Example: cancelled within 5 mins of acceptance)
    // This requires tracking booking events; a simpler approach is needed for now without updating schema
    // Let's stick to the high-level metrics for MVP.

    return score;
  },

  async applyPenalty(workerId: string, score: number) {
    if (score >= 70) {
      // Action: Flag for review and restrict
      // In a real app, this might involve updating a flag in workerProfile
      await prisma.workerProfile.update({
        where: { userId: workerId },
        data: { verificationNote: "Flagged for high cancellation rate" }
      });
      // Optionally ban the worker:
      // await prisma.user.update({ where: { id: workerId }, data: { isBanned: true } });
    }
  }
};
