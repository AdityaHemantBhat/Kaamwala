import { prisma } from '../config/prisma';
import { generateReferralCode } from '../utils/referral-code';

export const referralService = {
  async getOrCreateCode(userId: string): Promise<string> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { referralCode: true },
    });

    if (user?.referralCode) return user.referralCode;

    const code = generateReferralCode();
    await prisma.user.update({
      where: { id: userId },
      data: { referralCode: code },
    });
    return code;
  },

  async processReferral(referralCode: string, referredUserId: string) {
    // Find the referrer
    const referrer = await prisma.user.findFirst({
      where: { referralCode },
    });

    if (!referrer || referrer.id === referredUserId) return null;

    // Check if already referred
    const existing = await prisma.referralEvent.findFirst({
      where: { referredId: referredUserId },
    });
    if (existing) return null;

    // Create referral event
    const event = await prisma.referralEvent.create({
      data: {
        referrerId: referrer.id,
        referredId: referredUserId,
        referralCode,
        referrerBonus: 75,
        referredBonus: 50,
      },
    });

    // Credit referred user's wallet
    await prisma.customerProfile.upsert({
      where: { userId: referredUserId },
      update: { walletBalance: { increment: 50 } },
      create: { userId: referredUserId, walletBalance: 50 },
    });

    // Record transaction for referred
    await prisma.transaction.create({
      data: {
        userId: referredUserId,
        type: 'REFERRAL_BONUS',
        amount: 50,
        description: 'Welcome bonus — referred by a friend',
        status: 'completed',
      },
    });

    return event;
  },

  async creditReferrerOnFirstBooking(referralEventId: string) {
    const event = await prisma.referralEvent.findUnique({
      where: { id: referralEventId },
    });

    if (!event || event.bonusPaidAt) return;

    // Credit referrer
    await prisma.customerProfile.upsert({
      where: { userId: event.referrerId },
      update: { walletBalance: { increment: 75 } },
      create: { userId: event.referrerId, walletBalance: 75 },
    });

    await prisma.transaction.create({
      data: {
        userId: event.referrerId,
        type: 'REFERRAL_BONUS',
        amount: 75,
        description: 'Referral bonus — friend completed first booking',
        status: 'completed',
      },
    });

    await prisma.referralEvent.update({
      where: { id: referralEventId },
      data: { bonusPaidAt: new Date() },
    });
  },

  async getReferralStats(userId: string) {
    const [given, received, totalEarned] = await Promise.all([
      prisma.referralEvent.count({ where: { referrerId: userId } }),
      prisma.referralEvent.findMany({
        where: { referrerId: userId, bonusPaidAt: { not: null } },
        select: { referrerBonus: true },
      }),
      prisma.referralEvent.findFirst({
        where: { referredId: userId },
      }),
    ]);

    const earned = received.reduce((sum, r) => sum + r.referrerBonus, 0);

    return {
      totalReferrals: given,
      totalEarned: earned,
      wasReferred: !!received,
    };
  },
};
