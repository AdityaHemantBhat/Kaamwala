import { prisma } from '../config/prisma';
import { ServiceCategory } from '@prisma/client';

export const workerService = {
  async searchWorkers(lat: number, lng: number, category?: ServiceCategory, minRating?: number, maxPrice?: number, radius: number = 10, page: number = 1, limit: number = 20, search?: string) {
    const whereClause: any = {
      isAvailable: true,
      isOnline: true,
      isFrozen: false,
      isBanned: false,
      isPermanentlyBanned: false,
      verificationStatus: 'VERIFIED',
    };
    if (category) whereClause.category = category;
    if (minRating) whereClause.rating = { gte: minRating };
    if (maxPrice) whereClause.hourlyRate = { lte: maxPrice };

    // Text search by worker name or category
    if (search && search.trim()) {
      const q = search.trim();
      whereClause.OR = [
        { user: { name: { contains: q, mode: 'insensitive' } } },
        { category: { contains: q.toUpperCase(), mode: 'insensitive' } },
        { bio: { contains: q, mode: 'insensitive' } },
      ];
    }

    const workers = await prisma.workerProfile.findMany({
      where: whereClause,
      include: { user: true, services: true }
    });

    let results = workers.map(worker => {
      const hasCoords = lat !== undefined && lat !== null && !isNaN(lat) && lng !== undefined && lng !== null && !isNaN(lng) && worker.latitude !== null && worker.latitude !== undefined && worker.longitude !== null && worker.longitude !== undefined;
      const distance = hasCoords ? this.getHaversineDistance(lat, lng, worker.latitude!, worker.longitude!) : null;
      const avatarUrl = worker.user?.avatarUrl || null;
      return { ...worker, distanceKm: distance, avatarUrl };
    });

    // If we have coordinates, filter by radius; otherwise keep all
    if (typeof lat === 'number' && !isNaN(lat) && typeof lng === 'number' && !isNaN(lng)) {
      results = results.filter(w => (w.distanceKm ?? 9999) <= radius);
    }

    results.forEach(w => {
      const ratingScore = (w.rating / 5) * 0.4;
      const jobsScore = (Math.min(w.completedJobs, 100) / 100) * 0.3;
      const distanceScore = (w.distanceKm == null || radius <= 0) ? 0 : ((radius - w.distanceKm) / radius) * 0.3;
      (w as any).score = ratingScore + jobsScore + distanceScore;
    });

    results.sort((a, b) => {
      if (a.isFeatured && !b.isFeatured) return -1;
      if (!a.isFeatured && b.isFeatured) return 1;
      return (b as any).score - (a as any).score;
    });

    return results.slice((page - 1) * limit, page * limit);
  },

  getHaversineDistance(lat1: number, lon1: number, lat2: number, lon2: number) {
    if (!lat1 || !lon1 || !lat2 || !lon2) return 9999;
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(lat1 * Math.PI/180) * Math.cos(lat2 * Math.PI/180) * Math.sin(dLon/2) * Math.sin(dLon/2);
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  }
};
