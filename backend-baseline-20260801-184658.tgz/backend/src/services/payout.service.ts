import axios from 'axios';
import { env } from '../config/env';
import { logger } from '../utils/logger';

export const payoutService = {
  async processPayout(transferId: string, amount: number, upiId: string, name: string) {
    // Fallback if no payout credentials are provided
    if (!env.CF_PAYOUT_APP_ID || !env.CF_PAYOUT_SECRET_KEY) {
      logger.info(`[MOCK PAYOUT] Transferred Rs.${amount} to UPI: ${upiId} for ${name}`);
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      return { success: true, referenceId: `mock_ref_${Date.now()}` };
    }

    try {
      const baseUrl = env.CF_ENV === 'PRODUCTION' 
        ? 'https://payout-api.cashfree.com/payout/v1.2' 
        : 'https://payout-gamma.cashfree.com/payout/v1.2';

      // 1. Authorize
      const authRes = await axios.post(`${baseUrl}/authorize`, {}, {
        headers: {
          'X-Client-Id': env.CF_PAYOUT_APP_ID,
          'X-Client-Secret': env.CF_PAYOUT_SECRET_KEY
        }
      });
      
      const token = authRes.data?.data?.token;
      if (!token) throw new Error('Failed to obtain Cashfree Payout Token');

      // 2. Add Beneficiary (ignore if already exists)
      const beneId = `bene_${transferId}`;
      try {
        await axios.post(`${baseUrl}/addBeneficiary`, {
            beneId,
            name: name || 'Worker Partner',
            email: 'worker@kaamwala.app',
            phone: '9999999999',
            vpa: upiId,
            address1: 'India'
          },
          { headers: { 'Authorization': `Bearer ${token}` } }
        );
      } catch (e: any) {
        if (e.response?.data?.subCode !== '409') throw e; // 409 means already exists
      }

      // 3. Request Transfer
      const transferRes = await axios.post(`${baseUrl}/requestTransfer`, {
          beneId,
          amount,
          transferId,
          transferMode: 'upi',
          remarks: 'KaamWalla Payout'
        },
        { headers: { 'Authorization': `Bearer ${token}` } }
      );

      if (transferRes.data?.status === 'SUCCESS') {
        return { success: true, referenceId: transferRes.data?.data?.referenceId };
      } else {
        throw new Error(transferRes.data?.message || 'Transfer failed');
      }

    } catch (error: any) {
      logger.error('Cashfree Payout Failed:', error?.response?.data || error.message);
      throw new Error(error?.response?.data?.message || 'Payment Gateway Payout Failed');
    }
  }
};
