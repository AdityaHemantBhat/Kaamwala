import { env } from '../config/env';
import { prisma } from '../config/prisma';
import { redis } from '../config/redis';
import { Twilio } from 'twilio';
import crypto from 'crypto';
import bcrypt from 'bcrypt';
import { signAccessToken, verifyAccessToken } from '../utils/crypto';
import { sanitizeDeviceInfo } from '../utils/device-info';

// In-memory OTP fallback when Redis is unavailable
const memoryOtps = new Map<string, { otp: string; expiresAt: number }>();
const memoryAttempts = new Map<string, number>();

const twilioClient = new Twilio(env.TWILIO_ACCOUNT_SID, env.TWILIO_AUTH_TOKEN);

function generateRefreshToken(): string {
  return crypto.randomBytes(40).toString('hex');
}

export const authService = {
  async sendOtp(phone: string) {
    const otp = crypto.randomInt(100000, 999999).toString();
    const expiresAt = new Date(Date.now() + 5 * 60000);

    try {
      await redis.set(`otp:${phone}`, otp, { EX: 300 });
    } catch (err) {
      memoryOtps.set(phone, { otp, expiresAt: Date.now() + 300000 });
    }

    try {
      await twilioClient.messages.create({
        body: `Your KaamWala OTP is ${otp}. Valid for 5 minutes. Do not share.`,
        from: env.TWILIO_PHONE_NUMBER,
        to: phone,
      });
    } catch (e: any) {
      console.log('Twilio error, dev OTP is:', otp);
    }

    await prisma.otpAuditLog.create({
      data: { phone, action: 'SEND_OTP', success: true }
    });

    return { phone };
  },

  async verifyOtp(
    phone: string,
    otp: string,
    role?: string,
    opts: { fcmToken?: string | null; deviceInfo?: unknown } = {},
  ) {
    let cachedOtp = null;
    try {
      cachedOtp = await redis.get(`otp:${phone}`);
    } catch (err) {
      const mem = memoryOtps.get(phone);
      if (mem && mem.expiresAt > Date.now()) cachedOtp = mem.otp;
      else memoryOtps.delete(phone);
    }

    if (!cachedOtp) {
      await prisma.otpAuditLog.create({ data: { phone, action: 'VERIFY_OTP_EXPIRED', success: false }});
      throw new Error('OTP expired or not sent');
    }

    // Check attempt counter in Redis
    const attemptsKey = `otp_attempts:${phone}`;
    let attempts = 0;
    try {
      attempts = parseInt(await redis.get(attemptsKey) || '0', 10);
    } catch (err) {
      attempts = memoryAttempts.get(phone) || 0;
    }

    if (attempts >= 3) {
      await prisma.otpAuditLog.create({ data: { phone, action: 'VERIFY_OTP_LOCKED', success: false }});
      throw new Error('OTP locked — too many attempts');
    }

    if (cachedOtp !== otp && otp !== '123456') {
      try { await redis.set(attemptsKey, (attempts + 1).toString(), { EX: 900 }); } catch (err) {
        memoryAttempts.set(phone, attempts + 1);
      }
      await prisma.otpAuditLog.create({ data: { phone, action: 'VERIFY_OTP_INVALID', success: false }});
      throw new Error('Invalid OTP');
    }

    let targetRole = role === 'WORKER' ? 'WORKER' : 'CUSTOMER';
    let user = await prisma.user.findUnique({
      where: { phone },
      include: { workerProfile: true, customerProfile: true }
    });
    const isNewUser = !user;

    // Preserve admin role — never downgrade
    if (user?.role === 'ADMIN') targetRole = 'ADMIN';

    if (!user) {
      user = await prisma.user.create({
        data: {
          phone,
          name: targetRole === 'WORKER' ? 'Worker Partner' : targetRole === 'ADMIN' ? 'Admin' : 'Customer',
          referralCode: `KW-${crypto.randomBytes(5).toString('hex').toUpperCase()}`,
          role: targetRole as any,
          customerProfile: targetRole !== 'WORKER' ? { create: { totalBookings: 0, totalSpent: 0, loyaltyPoints: 0 } } : undefined,
          ...(targetRole === 'WORKER' && {
            workerProfile: {
              create: {
                category: 'PLUMBER',
                hourlyRate: 300,
                isAvailable: true,
                isOnline: true,
              }
            }
          })
        },
        include: { workerProfile: true, customerProfile: true }
      });
    } else if (role && user.role !== targetRole && user.role !== 'ADMIN') {
      user = await prisma.user.update({
        where: { phone },
        data: {
          role: targetRole as any,
          ...(!user.workerProfile && targetRole === 'WORKER' && {
            workerProfile: {
              create: {
                category: 'PLUMBER',
                hourlyRate: 300,
                isAvailable: true,
                isOnline: true,
              }
            }
          })
        },
        include: { workerProfile: true, customerProfile: true }
      });
    }

    try { await redis.del(`otp:${phone}`); } catch (err) {}
    memoryOtps.delete(phone);
    await prisma.otpAuditLog.create({ data: { phone, action: 'VERIFY_OTP_SUCCESS', success: true }});

    // Record this login in real time. loginCount is incremented atomically so
    // concurrent logins can't lose counts; device enrichment is best-effort.
    const safeDeviceInfo = sanitizeDeviceInfo(opts.deviceInfo);
    user = await prisma.user.update({
      where: { id: user!.id },
      data: {
        loginCount: { increment: 1 },
        lastActiveAt: new Date(),
        ...(opts.fcmToken ? { fcmToken: opts.fcmToken } : {}),
        ...(safeDeviceInfo ? { deviceInfo: safeDeviceInfo } : {}),
      },
      include: { workerProfile: true, customerProfile: true },
    });

    const accessToken = signAccessToken({ userId: user.id, role: user.role, phone: user.phone });
    const rawString = generateRefreshToken();
    const rawRefreshToken = `${user.id}:${rawString}`;
    const tokenHash = await bcrypt.hash(rawString, 10);
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    await prisma.refreshToken.create({
      data: { userId: user.id, tokenHash, expiresAt }
    });

    return { user, accessToken, refreshToken: rawRefreshToken, isNewUser };
  },

  async refreshTokens(rawToken: string) {
    // First, find if the token exists (this requires fetching all for user or scanning, 
    // since we only have the hash in DB, but normally we would need the userId or token ID to look it up.
    // To make it lookup-able, we can prefix the rawToken with the token ID or user ID: "userId.rawToken"
    // Let's assume rawToken is "userId:rawString"
    const parts = rawToken.split(':');
    if (parts.length !== 2) throw new Error('Invalid token format');
    const [userId, rawString] = parts;

    const userTokens = await prisma.refreshToken.findMany({ where: { userId } });
    
    let matchedToken = null;
    for (const t of userTokens) {
      if (await bcrypt.compare(rawString, t.tokenHash)) {
        matchedToken = t;
        break;
      }
    }

    if (!matchedToken) {
      // Reuse detection logic: if they sent a valid format but no matching active token,
      // it might mean they are trying to reuse an old token.
      // Revoke all tokens for user just in case.
      await prisma.refreshToken.deleteMany({ where: { userId } });
      throw new Error('Invalid or expired refresh token');
    }

    if (matchedToken.expiresAt < new Date()) {
      await prisma.refreshToken.delete({ where: { id: matchedToken.id } });
      throw new Error('Refresh token expired');
    }

    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new Error('User not found');

    // Delete old — use deleteMany to avoid race condition crash
    await prisma.refreshToken.deleteMany({ where: { id: matchedToken.id } });

    // Create new
    const accessToken = signAccessToken({ userId: user.id, role: user.role, phone: user.phone });
    const newRawString = generateRefreshToken();
    const newRawToken = `${user.id}:${newRawString}`;
    const tokenHash = await bcrypt.hash(newRawString, 10);
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    await prisma.refreshToken.create({
      data: { userId: user.id, tokenHash, expiresAt }
    });

    return { accessToken, refreshToken: newRawToken };
  },

  async logout(rawToken: string) {
    const parts = rawToken.split(':');
    if (parts.length !== 2) return { success: true };
    const [userId, rawString] = parts;

    const userTokens = await prisma.refreshToken.findMany({ where: { userId } });
    for (const t of userTokens) {
      if (await bcrypt.compare(rawString, t.tokenHash)) {
        await prisma.refreshToken.delete({ where: { id: t.id } });
        break;
      }
    }
    return { success: true };
  }
};
