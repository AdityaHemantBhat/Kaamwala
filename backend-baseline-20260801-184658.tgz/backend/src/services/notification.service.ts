import { messaging } from '../config/firebase';
import { prisma } from '../config/prisma';
import { logger } from '../utils/logger';

export const notificationService = {
  async sendPushNotification(userId: string, title: string, body: string, type: string, data?: any) {
    try {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { fcmToken: true }
      });

      // Save to database
      await prisma.notification.create({
        data: {
          userId,
          title,
          body,
          type,
          data: data ? data : undefined,
        }
      });

      if (user?.fcmToken) {
        await messaging.send({
          token: user.fcmToken,
          notification: {
            title,
            body
          },
          data: data ? { payload: JSON.stringify(data) } : undefined
        });
      }
    } catch (e) {
      logger.error('Failed to send push notification', e);
    }
  }
};
