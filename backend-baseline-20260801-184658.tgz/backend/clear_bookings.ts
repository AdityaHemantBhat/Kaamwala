import { prisma } from './src/config/prisma';

async function main() {
  await prisma.message.deleteMany({});
  await prisma.chat.deleteMany({});
  await prisma.review.deleteMany({});
  await prisma.transaction.deleteMany({});
  await prisma.booking.deleteMany({});
  console.log('Deleted all bookings and related data');
}

main().catch(console.error).finally(() => prisma.$disconnect());
