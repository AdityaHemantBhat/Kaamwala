import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  const result = await prisma.address.updateMany({
    data: {
      latitude: 19.0760, // Mumbai
      longitude: 72.8777
    }
  });
  console.log('Updated addresses:', result.count);
}

main().catch(console.error).finally(() => prisma.$disconnect());
