const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
async function run() {
  const users = await prisma.user.findMany({ where: { name: { contains: 'aditya', mode: 'insensitive' } }, include: { bookingsAsCustomer: { include: { address: true } } } });
  for(const u of users) {
    if(u.bookingsAsCustomer) {
      for(const b of u.bookingsAsCustomer) {
        console.log(Booking: , Status: , Lat: , Lng: );
      }
    }
  }
}
run().catch(console.error).finally(() => prisma.$disconnect());
