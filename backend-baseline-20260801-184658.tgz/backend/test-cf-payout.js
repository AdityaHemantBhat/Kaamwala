require('dotenv').config();
const axios = require('axios');

async function testPayout() {
  const appId = process.env.CF_APP_ID;
  const secretKey = process.env.CF_SECRET_KEY;
  console.log("App ID:", appId);

  try {
    const res = await axios.post('https://payout-gamma.cashfree.com/payout/v1/authorize', {}, {
      headers: {
        'X-Client-Id': appId,
        'X-Client-Secret': secretKey
      }
    });
    console.log("Success! Token received.");
    console.log(res.data);
  } catch (err) {
    console.log("Error:", err.response ? err.response.data : err.message);
  }
}

testPayout();
