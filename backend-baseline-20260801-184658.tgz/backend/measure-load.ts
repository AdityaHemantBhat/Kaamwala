import 'dotenv/config';
const start = Date.now();
// Pull the full startup module graph, same as index.ts
(async () => {
  const mods: string[] = [];
  const t = async (label: string, imp: Promise<any>) => {
    const s = Date.now();
    await imp;
    mods.push(`${label}: ${Date.now() - s}ms`);
  };
  await t('env', import('./src/config/env'));
  await t('logger', import('./src/utils/logger'));
  await t('prisma', import('./src/config/prisma'));
  await t('redis', import('./src/config/redis'));
  await t('middleware+utils', Promise.all([
    import('./src/middleware/sanitize.middleware'),
    import('./src/middleware/rateLimit.middleware'),
    import('./src/middleware/security.middleware'),
    import('./src/middleware/error.middleware'),
    import('./src/middleware/auth.middleware'),
    import('./src/middleware/role.middleware'),
    import('./src/middleware/upload.middleware'),
    import('./src/middleware/validate.middleware'),
    import('./src/middleware/version.middleware'),
    import('./src/utils/response'),
    import('./src/utils/audit'),
    import('./src/utils/crypto'),
  ]));
  await t('socket.service', import('./src/services/socket.service'));
  await t('routes (all controllers/services)', import('./src/routes'));
  await t('scheduledJobs.service', import('./src/services/scheduledJobs.service'));
  console.log('--- MODULE LOAD TIMINGS (transpile-only) ---');
  mods.forEach(m => console.log(' ', m));
  console.log('TOTAL:', Date.now() - start, 'ms');
  process.exit(0);
})();
